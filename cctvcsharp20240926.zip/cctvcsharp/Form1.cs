using System.Net;
using System.Net.Mail;
using System.Net.WebSockets;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Text;
using System.Drawing.Imaging;
using AForge.Video;
using AForge.Video.DirectShow;
using AForge.Vision.Motion;
using System.Diagnostics;
using Newtonsoft.Json;
using System.Windows.Forms;
using System;
using System.Drawing;
using System.Threading.Tasks;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Dynamic;
using System.Net.NetworkInformation;
using System.Text.RegularExpressions;
using System.Security.Principal;
using AForge.Controls;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using System.Runtime.CompilerServices;


namespace cctvcsharp
{
    public partial class Form1 : Form
    {
        private VideoCaptureDevice? videoSource, videoSource1;
        private FilterInfoCollection videoDevices1, videoDevices2;
        private VideoCapabilities[] videoCapabilities1, videoCapabilities2;
        private bool deviceSeted1, deviceSeted2;
        private int deviceIndex1, deviceIndex2;
        private int deviceResoulutionIndex1, deviceResoulutionIndex2;
        int timerint, timerint2, timerint3, timerint2p, timerint3p, t3, t4, fps1, fps2, fps3, fps4;
        long t5, t6, t7, t8;
        int day2, month2, year2, minute2, second2, hour2, cnt, autorecovery2cnt, autorecovery2cnt2;
        bool pic1process, pic2process, pic3process, pic4process, pic5process, outputFileBool,
            boollisten, connected, SensedsavingBool, checkvideo;
        string? path;
        public bool boadcastbool;
        //string? outputFilePath;
        //FileStream? outputFileStream;
        //VideoCaptureDeviceForm cameras2;// = new VideoCaptureDeviceForm();

        //[DllImport("WebSocketServer.dll", CharSet = CharSet.Unicode)]
        //public static extern string SendMessage();

        WebSocketServer server;
        private string serverUri;

        MotionDetector motionDetector, motionDetector2;
        //private object lockObject = new object();
        private bool allowClose = false;

        private const int WM_HOTKEY = 0x0312;  //================== ����Ű
        public Form1()
        {
            /// Costura.Fody nuget ��Ű�� ���� ��������
            InitializeComponent();

            // ����Ű ���
            RegisterHotKey(this.Handle, 1, (int)KeyModifier.Control | (int)KeyModifier.Shift, Keys.A.GetHashCode());
            
        }

        // ����Ű ����� ���� API �Լ�
        [DllImport("user32.dll")]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);

        // Ű ������ ������
        [Flags]
        private enum KeyModifier
        {
            None = 0,
            Alt = 1,
            Control = 2,
            Shift = 4,
            WinKey = 8
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);

            // ����Ű �޽��� Ȯ��
            if (m.Msg == WM_HOTKEY)
            {
                // ��ϵ� ����Ű�� ������ �� ó���� �۾� ����
                if (m.WParam.ToInt32() == 1)
                {
                    IntPtr hWnd = FindWindow(null, this.Name);
                    ShowWindow(hWnd, SW_SHOW);
                    MessageBox.Show("Ctrl + Shift + A ����");
                }
            }
        }


        // ����Ű ������ ���� API �Լ�
        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        [DllImport("user32.dll")]
        private static extern bool BlockInput(bool fBlockIt);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr FindWindow(string? lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        private static extern int SetWindowDisplayAffinity(IntPtr hWnd, int dwAffinity);

        public void DisableScreenCapture()
        {
            //BlockInput(true);

            IntPtr hWnd = FindWindow(null, this.Name); //IntPtr hWnd = FindWindow(null, "Form1");
            SetWindowDisplayAffinity(hWnd, 1);

        }

        public void EnableScreenCapture()
        {
            //BlockInput(false);

            IntPtr hWnd = FindWindow(null, this.Name);
            //SetWindowDisplayAffinity(hWnd, 0);
        }

        public class Settings
        {
            public Point Location { get; set; }
            public Size Size { get; set; }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //���߸���� ���α׷��� ����� ȭ�鿡�� ���α׷�����
            Screen currentScreen = Screen.FromHandle(this.Handle);

            this.Location = new System.Drawing.Point(currentScreen.WorkingArea.Left, currentScreen.WorkingArea.Top);


            if (ProcessSecurity.EnableDLLInjectionProtection())
            {
                UpdateRichTextBox("EnableDLLInjectionProtection");
                ProcessSecurity.EnableDEP();
            }

            fps1 = 0; fps2 = 0; fps3 = 0; fps4 = 0;
            pic1process = false; pic2process = false; pic3process = false; pic4process = false; pic5process = true;
            outputFileBool = false; SensedsavingBool = true;
            autorecovery2cnt = 0;
            autorecovery2cnt2 = 0;
            //outputFilePath = null;
            timerint = 0; timerint3 = 0;
            timerint2p = 0; timerint3p = 0;
            textBox3.Text = "0";
            textBox4.Text = "0"; textBox5.Text = "0";
            timer1.Interval = (int)(1000 / int.Parse(textBox1.Text));
            //textBox3.Text = timer1.Interval.ToString();

            checkvideo = true;

            timer1.Start();
            timer2.Start();

            DisableScreenCapture();
            UpdateRichTextBox("DisabledScreenCapture");

            cctv1.Checked = true;

            //======================================================  Newtonsoft.Json  ======================================================
            //textBox13.Text = "";
            string filePath = Path.Combine("./", "data001.json"); //Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
            if (File.Exists(filePath))
            {
                string id = JsonConvert.DeserializeObject<string>(File.ReadAllText(filePath));
                // Use the retrieved ID value as needed
                textBox13.Text = id;

                // �� ��ġ �ҷ�����
                string settingsFilePath = filePath + ".settings";
                if (File.Exists(settingsFilePath))
                {
                    var settings = JsonConvert.DeserializeObject<Settings>(File.ReadAllText(settingsFilePath));
                    this.Location = settings.Location;
                    this.Size = settings.Size;
                }
            }

            //textBox13.Text = "pakata@korea.com";
            //if (textBox12.Text != "")
            //{
            textBox12.Text = "8888";
            //}

            if (textBox13.Text != "")
            {
                // Public IP �ּ� ���ϱ�
                WebClient wc = new WebClient();
                string result = wc.DownloadString("http://coreafactory.com/ip/index.php?email=" + textBox13.Text + "&port=" + textBox12.Text + "&side=server"); //Current IP Address: 119.202.146.249
                string ip = result.Split(':')[1].Split('<')[0].Trim();

                textBox11.Text = ip;
                textBox12.Text = result.Split(':')[2].Split('<')[0].Trim();
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            motionDetector = new MotionDetector(new TwoFramesDifferenceDetector(), new MotionAreaHighlighting());
            CamGetList(comboBox1);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (videoSource != null && videoSource.IsRunning)
            {
                path = getpathr("s");

                if ((pictureBox1.Image != null) && (pic2process))
                {
                    using (FileStream file3 = System.IO.File.Create(path))
                    {
                        //await Task.Delay(20);
                        try
                        {
                            //imagestream2.WriteTo(file3);
                            pictureBox1.Image.Save(file3, ImageFormat.Jpeg);
                        }
                        catch (Exception ex)
                        {
                            UpdateRichTextBox(ex.ToString());
                        }
                    }
                }

                if (videoSource != null && videoSource.IsRunning)
                {
                    videoSource.SignalToStop();
                    videoSource.WaitForStop();
                    videoSource.NewFrame -= VideoSource_NewFrame;
                    videoSource = null;
                }

                deviceSeted1 = false;
                comboBox1.SelectedIndex = -1;
                comboBox2.SelectedIndex = -1;
                comboBox1.Items.Clear();
                comboBox2.Items.Clear();
                deviceIndex1 = 0;
                deviceResoulutionIndex1 = 0;
            }
        }

        private async void VideoSource_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            if ((timerint > timerint2p) && pic1process)
            {
                pic1process = false;

                fps1++;
                timerint2p = timerint;
                MemoryStream imageStream = new MemoryStream();
                Bitmap tempbmp = (System.Drawing.Bitmap)eventArgs.Frame.Clone();
                Bitmap tempbmp2 = (System.Drawing.Bitmap)eventArgs.Frame.Clone();

                if (information.Checked)
                {
                    using (Graphics graphics = Graphics.FromImage(tempbmp))
                    {
                        if ((selectedRectangle != null) && piczoomready)
                        {
                            Bitmap scaledImage = ScaleImageToFitPictureBox(tempbmp);
                            graphics.DrawImage(scaledImage, new PointF(0, 0));
                        }

                        string temp = $"date time: {DateTime.Now.ToString()} \n" +
                            $"Device Name: {videoDevices1[deviceIndex1].Name} \n" +
                             $"Resolution: {videoCapabilities1[deviceResoulutionIndex1].FrameSize.Width} x " +
                             $"{videoCapabilities1[deviceResoulutionIndex1].FrameSize.Height}, \n" +
                             $"Max Frame Rate: {videoCapabilities1[deviceResoulutionIndex1].MaximumFrameRate}, \n" +
                             $"Bit Count: {videoCapabilities1[deviceResoulutionIndex1].BitCount}";
                        // Draw the text on the bitmap with the specified color and font
                        string checkvideos = "0";
                        int sizew = videoSource.VideoResolution.FrameSize.Width;
                        int sizeh = videoSource.VideoResolution.FrameSize.Height;
                        SolidBrush tempcolor = new SolidBrush(Color.Yellow);
                        if (checkvideo) { checkvideos = "1"; checkvideo = false; tempcolor = new SolidBrush(Color.Black); } else { checkvideo = true; }
                        graphics.DrawString(temp, new System.Drawing.Font("Gothic", 12), tempcolor, new PointF(20, 20));
                        graphics.DrawString(checkvideos, new System.Drawing.Font("Gothic", 12), tempcolor, new PointF(sizew - 40, 20));
                        graphics.DrawString(checkvideos, new System.Drawing.Font("Gothic", 12), tempcolor, new PointF(20, sizeh - 40));
                        graphics.DrawString(checkvideos, new System.Drawing.Font("Gothic", 12), tempcolor, new PointF(sizew - 40, sizeh - 40));

                        if (infoconnection.Checked)
                        {
                            richTextBox1.Invoke((MethodInvoker)delegate
                            {
                                temp = richTextBox1.Text;
                            });

                            graphics.DrawString(temp, new System.Drawing.Font("Gothic", 12), tempcolor, new PointF(20, 120));
                            richTextBox2.Invoke((MethodInvoker)delegate
                            {
                                temp = richTextBox2.Text;
                            });
                            graphics.DrawString(temp, new System.Drawing.Font("Gothic", 12), tempcolor, new PointF(420, 120));
                        }
                    }
                }

                using (Graphics graphics = Graphics.FromImage(tempbmp2))
                {
                    if ((selectedRectangle != null) && piczoomready)
                    {
                        Bitmap scaledImage = ScaleImageToFitPictureBox(tempbmp2);
                        graphics.DrawImage(scaledImage, new PointF(0, 0));
                    }
                }

                try
                {
                    //lock (lockObject)
                    //{
                    // Create a new stream to save the image
                    tempbmp.Save(imageStream, ImageFormat.Jpeg);
                    //}
                }
                catch (Exception ex)
                {
                    UpdateRichTextBox(ex.ToString());
                }

                if (pic5process && previewcheck1.Checked)
                {
                    pic5process = false;
                    pictureBox1.Invoke((MethodInvoker)delegate
                    {
                        pictureBox1.Image = null;
                        pictureBox1.Image = tempbmp;
                    });
                    pic5process = true;
                }

                //await Task.Delay(40);
                //Thread.Sleep(70);



                await Task.Delay(40);
                //Thread.Sleep(70);
                float detection = 0;
                if (sensorcheck.Checked && sense1.Checked)
                {
                    detection = motionDetector.ProcessFrame(tempbmp2);
                }
                await Task.Delay(40);
                // Further processing with the image stream
                float t3 = float.Parse(textBox2.Text);
                //t4 = int.Parse(textBox4.Text);
                //t5 = imageStream.Length;

                this.textBox4.Invoke(new MethodInvoker(delegate ()
                {
                    textBox4.Text = imageStream.Length.ToString();
                }));

                this.label13.Invoke(new MethodInvoker(delegate ()
                {
                    label13.Text = detection.ToString();
                }));

                if (cctv1.Checked && previewcheckMain.Checked)
                {
                    mainpicrreload(tempbmp);
                }

                if ((imageStream.Length > 1000) && TcpSend1.Checked )
                {
                    Broadcast(imageStream, 1);
                }

                //if (((t4 + t3) < t5) | ((t4 - t3) > t5))
                if (1 > detection && detection > t3)
                {
                    if (chase1.Checked && previewcheckMain.Checked)
                    {
                        mainpicrreload(tempbmp2);
                    }

                    if (imageStream.Length > 1000)
                    {
                        //Broadcast(imageStream, 1);

                        if (checkbeep.Checked) { Console.Beep(); }

                        if (checksave.Checked && SensedsavingBool && sense1.Checked)
                        {
                            //Sensedsaving(imageStream);
                            bool temp = await Sensedsaving(imageStream);

                            //Console.Beep();
                        }
                    }

                }

                imageStream.Dispose();
                pic1process = true;
            }
        }

        private async void VideoSource_NewFrame2(object sender, NewFrameEventArgs eventArgs)
        {
            if ((timerint3 > timerint3p) && pic2process) //(timerint > timerint2p) &&
            {
                pic2process = false;

                fps2++;
                timerint3p = timerint3;
                MemoryStream imageStream2 = new MemoryStream();

                Bitmap tempbmp = (System.Drawing.Bitmap)eventArgs.Frame.Clone();
                Bitmap tempbmp2 = (System.Drawing.Bitmap)eventArgs.Frame.Clone();

                if (information.Checked)
                {
                    using (Graphics graphics = Graphics.FromImage(tempbmp))
                    {
                        if ((selectedRectangle != null) && piczoomready)
                        {
                            Bitmap scaledImage = ScaleImageToFitPictureBox(tempbmp);
                            graphics.DrawImage(scaledImage, new PointF(0, 0));
                        }

                        string temp = $"date time: {DateTime.Now.ToString()} \n" +
                            $"Device Name: {videoDevices2[deviceIndex2].Name} \n" +
                             $"Resolution: {videoCapabilities2[deviceResoulutionIndex2].FrameSize.Width} x " +
                             $"{videoCapabilities2[deviceResoulutionIndex2].FrameSize.Height}, \n" +
                             $"Max Frame Rate: {videoCapabilities2[deviceResoulutionIndex2].MaximumFrameRate}, \n" +
                             $"Bit Count: {videoCapabilities2[deviceResoulutionIndex2].BitCount}";
                        // Draw the text on the bitmap with the specified color and font

                        string checkvideos = "0";
                        int sizew = videoSource1.VideoResolution.FrameSize.Width;
                        int sizeh = videoSource1.VideoResolution.FrameSize.Height;
                        SolidBrush tempcolor = new SolidBrush(Color.Yellow);
                        if (checkvideo) { checkvideos = "1"; checkvideo = false; tempcolor = new SolidBrush(Color.Black); } else { checkvideo = true; }
                        graphics.DrawString(temp, new System.Drawing.Font("Gothic", 12), tempcolor, new PointF(20, 20));
                        graphics.DrawString(checkvideos, new System.Drawing.Font("Gothic", 12), tempcolor, new PointF(sizew - 40, 20));
                        graphics.DrawString(checkvideos, new System.Drawing.Font("Gothic", 12), tempcolor, new PointF(20, sizeh - 40));
                        graphics.DrawString(checkvideos, new System.Drawing.Font("Gothic", 12), tempcolor, new PointF(sizew - 40, sizeh - 40));


                        if (infoconnection.Checked)
                        {
                            richTextBox1.Invoke((MethodInvoker)delegate
                        {
                            temp = richTextBox1.Text;
                        });

                            graphics.DrawString(temp, new System.Drawing.Font("Gothic", 12), tempcolor, new PointF(20, 120));
                            richTextBox2.Invoke((MethodInvoker)delegate
                            {
                                temp = richTextBox2.Text;
                            });
                            graphics.DrawString(temp, new System.Drawing.Font("Gothic", 12), tempcolor, new PointF(420, 120));
                        }
                    }
                }

                using (Graphics graphics = Graphics.FromImage(tempbmp2))
                {
                    if ((selectedRectangle != null) && piczoomready)
                    {
                        Bitmap scaledImage = ScaleImageToFitPictureBox(tempbmp2);
                        graphics.DrawImage(scaledImage, new PointF(0, 0));
                    }
                }

                try
                {
                    //lock (lockObject)
                    //{
                    // Create a new stream to save the image
                    tempbmp.Save(imageStream2, ImageFormat.Jpeg);
                    //}
                }
                catch (Exception ex)
                {
                    UpdateRichTextBox(ex.ToString());
                }

                if (pic5process && previewcheck2.Checked)
                {
                    pic5process = false;
                    pictureBox2.Invoke((MethodInvoker)delegate
                    {
                        pictureBox2.Image = null;
                        pictureBox2.Image = tempbmp;
                    });
                    pic5process = true;
                }

                //await Task.Delay(40);




                await Task.Delay(40);
                float detection = 0;
                if (sensorcheck.Checked && sense2.Checked)
                {
                    detection = motionDetector2.ProcessFrame(tempbmp2);
                }
                await Task.Delay(40);
                // Further processing with the image stream
                float t3 = float.Parse(textBox2.Text);
                //t6 = int.Parse(textBox5.Text);
                //t7 = imageStream2.Length;

                this.textBox5.Invoke(new MethodInvoker(delegate ()
                {
                    textBox5.Text = imageStream2.Length.ToString();
                }));

                this.label12.Invoke(new MethodInvoker(delegate ()
                {
                    label12.Text = detection.ToString();
                }));

                if (cctv2.Checked && previewcheckMain.Checked)
                {
                    mainpicrreload(tempbmp);
                }

                if ((imageStream2.Length > 1000) && TcpSend2.Checked)
                {
                    Broadcast(imageStream2, 2);
                }

                //if (((t6 + t3) < t7) | ((t6 - t3) > t7))
                if (1 > detection && detection > t3)
                {
                    if (chase2.Checked && previewcheckMain.Checked)
                    {
                        mainpicrreload(tempbmp2);
                    }

                    if (imageStream2.Length > 1000)
                    {
                        //Broadcast(imageStream2, 2);

                        if (checkbeep.Checked) { Console.Beep(); }

                        if (checksave.Checked && SensedsavingBool && sense2.Checked)
                        {
                            bool temp = await Sensedsaving(imageStream2);

                            //Console.Beep();
                        }
                    }
                }

                imageStream2.Dispose();
                pic2process = true;
            }
        }

        private async Task Broadcast(MemoryStream imageStream, int deviceId)
        {
            if (boadcastbool)
            {
                if (imageStream != null)
                {
                    boadcastbool = false;

                    string Resolution = "";
                    if (deviceId == 1)
                    {
                        Resolution = $"{videoCapabilities1[deviceResoulutionIndex1].FrameSize.Width}x{videoCapabilities1[deviceResoulutionIndex1].FrameSize.Height}";
                    }
                    else if (deviceId == 2)
                    {
                        Resolution = $"{videoCapabilities2[deviceResoulutionIndex2].FrameSize.Width}x{videoCapabilities2[deviceResoulutionIndex2].FrameSize.Height}";
                    }
                    // Convert the image to a byte array
                    byte[] imageBytes = imageStream.ToArray();
                    string base64String = Convert.ToBase64String(imageBytes);

                    // Create WebSocket message
                    byte[] imageBuffer = Encoding.UTF8.GetBytes(base64String);

                    string flushString = "efig" + deviceId.ToString();//Convert.ToBase64String(temp);
                    byte[] flushBuffer = Encoding.UTF8.GetBytes(Convert.ToBase64String(Encoding.UTF8.GetBytes(flushString)));

                    string ResolutionString = Resolution;//Convert.ToBase64String(temp);
                    byte[] ResolutionBuffer = Encoding.UTF8.GetBytes(Convert.ToBase64String(Encoding.UTF8.GetBytes(ResolutionString)));

                    string ResolutionStringEnd = "|ef";
                    byte[] ResolutionBufferEnd = Encoding.UTF8.GetBytes(Convert.ToBase64String(Encoding.UTF8.GetBytes(ResolutionStringEnd)));

                    // �� ���� ����Ʈ �迭 ��ġ��
                    byte[] combinedBuffer = new byte[imageBuffer.Length + flushBuffer.Length + ResolutionBuffer.Length + ResolutionBufferEnd.Length];
                    Buffer.BlockCopy(imageBuffer, 0, combinedBuffer, 0, imageBuffer.Length);
                    Buffer.BlockCopy(flushBuffer, 0, combinedBuffer, imageBuffer.Length, flushBuffer.Length);
                    Buffer.BlockCopy(ResolutionBuffer, 0, combinedBuffer, imageBuffer.Length + flushBuffer.Length, ResolutionBuffer.Length);
                    Buffer.BlockCopy(ResolutionBufferEnd, 0, combinedBuffer, imageBuffer.Length + flushBuffer.Length + ResolutionBuffer.Length, ResolutionBufferEnd.Length);

                    // Broadcast message to all connected clients
                    try
                    {
                        if (!server.sendingsensor)
                        {
                            server.receivebuffer = false;
                            server.tempbuffer = combinedBuffer;
                            server.receivebuffer = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        UpdateRichTextBox(ex.ToString());
                    }

                    boadcastbool = true;
                }
            }
        }

        private async Task<bool> Sensedsaving(MemoryStream imagestream2)
        {
            if (SensedsavingBool)
            {
                SensedsavingBool = false;
                path = getpathr("a");

                using (FileStream file3 = System.IO.File.Create(path))
                {
                    await Task.Delay(20);
                    try
                    {
                        imagestream2.WriteTo(file3);
                        //pictureBox2.Image.Save(file3, ImageFormat.Jpeg);
                    }
                    catch (Exception ex)
                    {
                        UpdateRichTextBox(ex.ToString());
                    }
                }

                /*
                if (outputFilePath == null)
                {
                    outputFilePath = $"./{day2}_{month2}_{year2}/{hour2}_{minute2}_{second2}_{cnt}.st1";
                    outputFileStream = System.IO.File.Create(outputFilePath);
                }

                if (!outputFileBool && (outputFileStream != null))
                {
                    outputFileBool = true;
                    try
                    {
                        // Convert the memory stream to a byte array
                        byte[] fileBytes = imagestream2.ToArray();

                        outputFileStream.Write(fileBytes, 0, fileBytes.Length);
                        string flushstring = "endofimage";
                        byte[] flushBytes = Encoding.UTF8.GetBytes(flushstring);
                        outputFileStream.Write(flushBytes, 0, flushBytes.Length);

                    }
                    catch (Exception ex)
                    {
                        // Handle any exceptions that occur during file reading
                        richTextBox1.AppendText(ex.ToString());
                    }
                    outputFileBool = false;
                }
                */

                SensedsavingBool = true;
            }
            return true;
        }
        private Bitmap ScaleImageToFitPictureBox(Bitmap originalImage)
        {
            // ũ�ӵ� �̹����� ���Ĺڽ��� ���߾� Ȯ�� �Ǵ� ���
            float scaleX = (originalImage.Width > pictureBox5.Width) ? (originalImage.Width / (float)pictureBox5.Width) : ((float)pictureBox5.Width / originalImage.Width);
            float scaleY = (originalImage.Height > pictureBox5.Height) ? (originalImage.Height / (float)pictureBox5.Height) : ((float)pictureBox5.Height / originalImage.Height);

            Bitmap croppedImage = new Bitmap((int)(selectedRectangle.Width * scaleX), (int)(selectedRectangle.Height * scaleY));
            using (Graphics g = Graphics.FromImage(croppedImage))
            {
                g.DrawImage(originalImage, new Rectangle(0, 0, croppedImage.Width, croppedImage.Height),
                    new Rectangle((int)(selectedRectangle.X * scaleX), (int)(selectedRectangle.Y * scaleY),
                    (int)(selectedRectangle.Width * scaleX), (int)(selectedRectangle.Height * scaleY)),
                    GraphicsUnit.Pixel);
            }
            //graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            //graphics.DrawImage(croppedImage,new Point(pictureBox5.Width,pictureBox5.Height));

            Bitmap scaledImage = new Bitmap(originalImage.Width, originalImage.Height);
            using (Graphics g = Graphics.FromImage(scaledImage))
            {
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.DrawImage(croppedImage, 0, 0, originalImage.Width, originalImage.Height);
            }

            return scaledImage;
        }

        private async void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!allowClose)
            {
                e.Cancel = true; // �� ���Ḧ ����մϴ�.
                MessageBox.Show("��ư�� ���� �������ּ���.");

                return;
            }

            // ���ø����̼� ����� ��ϵ� ����Ű ����
            UnregisterHotKey(this.Handle, 1);

            pic1process = false; pic2process = false; pic3process = false; pic4process = false;
            boollisten = false;
            boadcastbool = false;

            if ((videoSource != null && videoSource.IsRunning) || (videoSource1 != null && videoSource1.IsRunning))
            {
                if (path != null)
                {
                    mailsmtpnaver("enemy at the gate!! warning!!", path);
                    await Task.Delay(40);
                }
            }
            if (server != null) { server.Stop(); }
            disposeVideoSources();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timerint = timerint + 1; timerint3 = timerint3 + 1;

            DisableScreenCapture();
            //textBox4.Text = t5.ToString();
            //textBox5.Text = t7.ToString();
            /*  CPU ���� Ȯ��
            PerformanceCounter cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");

            float cpuUsage = cpuCounter.NextSample().RawValue; // CPU ���� Ȯ��

            textBox7.Text = cpuUsage.ToString()+"%";
            if (cpuUsage > 90) // CPU ������ 90% �̻��� ���
            {
                // ������ ��ġ�� ���� �� ����
            }
            */

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (randomname.Checked)
            {
                changeformname();
            }

            textBox3.Text = fps1.ToString(); textBox8.Text = fps2.ToString(); textBox9.Text = fps3.ToString(); textBox10.Text = fps4.ToString();

            if (devichk.Checked)
            {
                if (cctv1.Checked)
                {
                    if (textBox3.Text == "0")
                    {
                        //SystemSounds.Beep.Play();
                        Console.Beep();
                    }
                }

                if (cctv2.Checked)
                {
                    if ((textBox8.Text == "0") && devichk.Checked && autorecovery2.Checked)
                    {
                        autorecovery2cnt++;
                        //SystemSounds.Beep.Play();
                        Console.Beep();
                        if (autorecovery2cnt > 5)
                        {
                            autorecovery2cnt = 0;
                            autorecovery2.Checked = false;

                            camera2reset();
                        }
                    }
                }
            }

            //textBox3.Text = timerint.ToString();
            //timerint2 = timerint;
            timerint2p = 0; timerint3p = 0;
            timerint = 0; timerint3 = 0;

            fps1 = 0; fps2 = 0; fps3 = 0; fps4 = 0;

        }

        private void pictureBox1_LoadCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "1";
            }
            if (int.Parse(textBox1.Text) <= 0)
            {
                textBox1.Text = "1";
            }
            if (int.Parse(textBox1.Text) > 30)
            {
                textBox1.Text = "30";
            }

            timer1.Interval = (int)(1000 / int.Parse(textBox1.Text));
        }


        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.SelectAll();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DisableScreenCapture();
        }

        private void mailsmtpnaver(string args, string imagePath)
        {
            string emailTitle = "CCTV system Operation";
            string emailContent = args;
            string fromEmail = "pakata@naver.com";
            string fromName = "pakata";
            string toEmail = "pakata@korea.com";
            string toName = "pakata";

            // SMTP ���� ����
            string smtpServer = "smtp.naver.com"; //ssl://  tls://
            int smtpPort = 587;
            string smtpUsername = "pakata";
            string smtpPassword = "sherif82";


            // �̸��� �޽��� �ۼ�
            MailMessage mail = new MailMessage();
            mail.Subject = emailTitle;
            mail.Body = emailContent;
            mail.IsBodyHtml = true;
            mail.From = new MailAddress(fromEmail, fromName);
            mail.To.Add(new MailAddress(toEmail, toName));

            // �̹��� ÷��
            if (imagePath != null)
            {
                Attachment attachment = new Attachment(imagePath);
                mail.Attachments.Add(attachment);
            }

            // SMTP Ŭ���̾�Ʈ ����
            SmtpClient smtpClient = new SmtpClient(smtpServer, smtpPort);
            smtpClient.EnableSsl = true;
            smtpClient.UseDefaultCredentials = false;
            smtpClient.Credentials = new NetworkCredential(smtpUsername, smtpPassword);

            try
            {
                // �̸��� ������
                smtpClient.Send(mail);
                UpdateRichTextBox("Email sent successfully.");
            }
            catch (Exception ex)
            {
                UpdateRichTextBox("An error occurred while sending the email: " + ex.Message);
            }
        }
        //======================================================================================================  device combo list --start

        private async Task CamGetList(System.Windows.Forms.ComboBox kombobox)
        {
            kombobox.Items.Clear();
            if (kombobox == comboBox1)
            {
                videoDevices1 = new FilterInfoCollection(FilterCategory.VideoInputDevice);

                if (videoDevices1.Count == 0)
                {
                    UpdateRichTextBox("No video devices found.");
                    return;
                }

                // Populate combo box with available devices
                foreach (FilterInfo device in videoDevices1)
                {
                    kombobox.Items.Add(device.Name);
                }

                if (deviceSeted1)
                {
                    // Check if a saved device index exists
                    if ((deviceIndex1 + 1) <= kombobox.Items.Count)
                    {
                        Console.Beep();
                        Thread.Sleep(1000);
                        kombobox.SelectedIndex = deviceIndex1;
                    }
                    else
                    {
                        //deviceSeted1 = false;
                        //deviceIndex1 = 0; // Default to the first device if no saved index
                        UpdateRichTextBox("Saved Device lost try again.....");

                        ++autorecovery2cnt2;

                        if (autorecovery2cnt2 > 5)
                        {
                            autorecovery2cnt2 = 0;
                            UpdateRichTextBox("Saved Device lost try 5 times failed.....");
                        }
                        else
                        {
                            Task.Run(async () =>
                            {
                                await Task.Delay(10000); // 10�� ���
                                CamGetList(kombobox);
                            });
                        }
                    }
                    //comboBox2.SelectedIndex = deviceResoulutionIndex;
                }
            }
            else if (kombobox == comboBox3)
            {
                videoDevices2 = new FilterInfoCollection(FilterCategory.VideoInputDevice);

                if (videoDevices2.Count == 0)
                {
                    UpdateRichTextBox("No video devices found.");
                    return;
                }

                // Populate combo box with available devices
                foreach (FilterInfo device in videoDevices2)
                {
                    kombobox.Items.Add(device.Name);
                }

                // Check if a saved device index exists
                if (deviceIndex2 > kombobox.Items.Count)
                {
                    deviceSeted2 = false;
                    deviceIndex2 = 0; // Default to the first device if no saved index
                }

                if (deviceSeted2)
                {
                    // Check if a saved device index exists
                    if ((deviceIndex2 + 1) <= kombobox.Items.Count)
                    {
                        Console.Beep();
                        Thread.Sleep(1000);
                        kombobox.SelectedIndex = deviceIndex2;
                    }
                    else
                    {
                        //deviceSeted2 = false;
                        //deviceIndex2 = 0; // Default to the first device if no saved index
                        UpdateRichTextBox("Saved Device lost try again.....");

                        if (autorecovery2cnt2 > 5)
                        {
                            autorecovery2cnt2 = 0;
                            UpdateRichTextBox("Saved Device lost try 5 times failed.....");
                        }
                        else
                        {
                            Task.Run(async () =>
                            {
                                await Task.Delay(10000); // 10�� ���
                                CamGetList(kombobox);
                            });
                        }
                    }
                    //comboBox2.SelectedIndex = deviceResoulutionIndex;
                }
            }
        }

        private void CamGetResolution(System.Windows.Forms.ComboBox kombobox1, System.Windows.Forms.ComboBox kombobox2)
        {
            if (kombobox1 == comboBox1)
            {
                if (videoSource != null && videoSource.IsRunning)
                {
                    videoSource.SignalToStop();
                    videoSource.WaitForStop();
                }

                // Set the selected device as video source
                videoSource = new VideoCaptureDevice(videoDevices1[kombobox1.SelectedIndex].MonikerString);

                // Get supported video resolutions
                videoCapabilities1 = videoSource.VideoCapabilities;

                // Populate combo box with available resolutions
                kombobox2.Items.Clear();
                foreach (var capability in videoCapabilities1)
                {
                    kombobox2.Items.Add($"{capability.FrameSize.Width}x{capability.FrameSize.Height}");
                }

                if (deviceSeted1)
                {
                    Console.Beep();
                    Thread.Sleep(1000);
                    //comboBox1.SelectedIndex = deviceIndex;
                    kombobox2.SelectedIndex = deviceResoulutionIndex1;
                }
            }
            else if (kombobox1 == comboBox3)
            {
                if (videoSource1 != null && videoSource1.IsRunning)
                {
                    videoSource1.SignalToStop();
                    videoSource1.WaitForStop();
                }

                // Set the selected device as video source
                videoSource1 = new VideoCaptureDevice(videoDevices2[kombobox1.SelectedIndex].MonikerString);

                // Get supported video resolutions
                videoCapabilities2 = videoSource1.VideoCapabilities;

                // Populate combo box with available resolutions
                kombobox2.Items.Clear();
                foreach (var capability in videoCapabilities2)
                {
                    kombobox2.Items.Add($"{capability.FrameSize.Width}x{capability.FrameSize.Height}");
                }
                // Select the first resolution by default
                //comboBox2.SelectedIndex = 0;
                if (deviceSeted2)
                {
                    Console.Beep();
                    Thread.Sleep(1000);
                    //comboBox1.SelectedIndex = deviceIndex;
                    kombobox2.SelectedIndex = deviceResoulutionIndex2;
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex >= 0)
            {
                CamGetResolution(comboBox1, comboBox2);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (videoSource != null && comboBox1.SelectedIndex >= 0 && !videoSource.IsRunning)
            {
                //disposeVideoSource2();

                videoSource = new VideoCaptureDevice(videoDevices1[comboBox1.SelectedIndex].MonikerString);
                videoSource.VideoResolution = videoCapabilities1[comboBox2.SelectedIndex];
                videoSource.DesiredFrameRate = 30;

                deviceIndex1 = comboBox1.SelectedIndex;
                deviceResoulutionIndex1 = comboBox2.SelectedIndex;
                deviceSeted1 = true;

                videoSource.NewFrame += VideoSource_NewFrame;
                videoSource.Start();
                pic1process = true;

            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex >= 0)
            {
                //UpdateRichTextBox(comboBox3.SelectedIndex.ToString() + "__" + comboBox3.Items.Count.ToString());
                CamGetResolution(comboBox3, comboBox4);
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (videoSource1 != null && comboBox3.SelectedIndex >= 0 && !videoSource1.IsRunning)
            {
                //disposeVideoSource2();

                videoSource1 = new VideoCaptureDevice(videoDevices2[comboBox3.SelectedIndex].MonikerString);
                videoSource1.VideoResolution = videoCapabilities2[comboBox4.SelectedIndex];
                videoSource1.DesiredFrameRate = 30;

                deviceIndex2 = comboBox3.SelectedIndex;
                deviceResoulutionIndex2 = comboBox4.SelectedIndex;
                deviceSeted2 = true;

                videoSource1.NewFrame += VideoSource_NewFrame2;
                videoSource1.Start();
                pic2process = true;

            }
        }

        //======================================================================================================  device combo list --end
        private void button5_Click(object sender, EventArgs e)
        {
            motionDetector2 = new MotionDetector(new TwoFramesDifferenceDetector(), new MotionAreaHighlighting());
            CamGetList(comboBox3);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (videoSource1 != null && videoSource1.IsRunning)
            {
                path = getpathr("s");

                if ((pictureBox2.Image != null) && (pic2process))
                {
                    using (FileStream file3 = System.IO.File.Create(path))
                    {
                        //await Task.Delay(20);
                        try
                        {
                            //imagestream2.WriteTo(file3);
                            pictureBox2.Image.Save(file3, ImageFormat.Jpeg);
                        }
                        catch (Exception ex)
                        {
                            UpdateRichTextBox(ex.ToString());
                        }
                    }
                }

                videoSource1.SignalToStop();
                videoSource1.WaitForStop();
                videoSource1.NewFrame -= VideoSource_NewFrame2;
                videoSource1 = null;

                deviceSeted2 = false;
                comboBox3.SelectedIndex = -1;
                comboBox4.SelectedIndex = -1;
                comboBox3.Items.Clear();
                comboBox4.Items.Clear();
                deviceIndex2 = 0;
                deviceResoulutionIndex2 = 0;

            }
        }

        private async void button18_Click(object sender, EventArgs e)
        {
            allowClose = true;

            if (server != null) { server.Stop(); }
            disposeVideoSources();

            boollisten = false;
            boadcastbool = false;
            outputFileBool = true;
            path = null;

            //mailsmtpnaver("CCTV TERMINATING!!", path);
            await Task.Delay(40);
            Console.Beep();
            this.Close();

        }

        private void button19_Click(object sender, EventArgs e)
        {
            DateTime currentDate = DateTime.Today;
            day2 = currentDate.Day;
            month2 = currentDate.Month;
            year2 = currentDate.Year;

            string directoryPath = $"{day2}_{month2}_{year2}";

            try
            {
                OpenExplorerAndNavigate(directoryPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening explorer: {ex.Message}");
            }
        }


        private void button20_Click(object sender, EventArgs e)
        {
            //==========================================================   st1  video codec extracter.....   ====================================
            DateTime currentDate = DateTime.Today;
            day2 = currentDate.Day;
            month2 = currentDate.Month;
            year2 = currentDate.Year;

            string directoryPath = $"./{day2}_{month2}_{year2}";

            string[] videoFiles = Directory.GetFiles(directoryPath, "*.st1");



            foreach (string videoFile in videoFiles)
            {
                try
                {
                    byte[] fileBytes = System.IO.File.ReadAllBytes(videoFile);

                    int markerIndex = 0;
                    byte[] markerBytes = Encoding.UTF8.GetBytes("endofimage");
                    long flushmarkerstart = 0;
                    for (int i = 0; i < fileBytes.Length - markerBytes.Length + 1; i++)
                    {
                        if (fileBytes[i] == markerBytes[markerIndex])
                        {
                            markerIndex++;
                            if (markerIndex == markerBytes.Length)
                            {
                                // Remove the marker from the bytes array
                                byte[] imageData = new byte[i - flushmarkerstart - markerBytes.Length + 1];
                                Array.Copy(fileBytes, flushmarkerstart, imageData, 0, imageData.Length);
                                flushmarkerstart = i + 1;
                                // Write the image data to a file
                                string outputFile = $"{directoryPath}/{cnt}.jpg";
                                System.IO.File.WriteAllBytes(outputFile, imageData);
                                cnt++;


                                // Reset marker index and continue to the next marker
                                markerIndex = 0;
                            }
                        }
                        else
                        {
                            markerIndex = 0;
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Handle any exceptions that occur during file reading
                    UpdateRichTextBox(ex.ToString());
                }
            }
        }

        //======================================= back ground �� ����� ===================================//
        [DllImport("user32.dll")]                                                                          //
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);                                   //
                                                                                                           //
        public const int SW_HIDE = 0;                                                                      //
        public const int SW_SHOW = 5;                                                                      //
                                                                                                           //
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]                                               //
        public static extern int SetWindowText(IntPtr hWnd, string lpString);                              //
        private void button9_Click(object sender, EventArgs e)                                             //
        {                                                                                                  //
            IntPtr hWnd = FindWindow(null, this.Name);                                                     //
            //SetWindowText(hWnd, "");            // ���� �����                                           //
            ShowWindow(hWnd, SW_HIDE);                                                                     //
                                                                      //ShowWindow(hWnd, SW_HIDE);      // â �����                                               //
        }                                                                                                  //
        //=================================================================================================//

        //======================================== ������ ��Ϻ��� ========================================//
        // �ܺ� DLL ����Ʈ
        [DllImport("user32.dll", SetLastError = true)]                                                     //
        static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);                         //

        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]                          //
        static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);               //
                                                                                                           //
        [DllImport("user32.dll", SetLastError = true)]                                                     //
        static extern bool IsWindowVisible(IntPtr hWnd);                                                   //
                                                                                                           //                                                     //
                                                                                                           // ������ ���ν��� �ݹ�                                                                            //
        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);                                 //
                                                                                                           //
                                                                                                           // EnumWindows�� �ݹ� �Լ�                                                                         //
        private bool EnumWindowCallBack(IntPtr hWnd, IntPtr lParam)                                        //
        {                                                                                                  //
            if (IsWindowVisible(hWnd))                                                                     //
            {                                                                                              //
                StringBuilder sb = new StringBuilder(256);                                                 //
                GetWindowText(hWnd, sb, sb.Capacity);                                                      //
                                                                                                           //
                                                                                                           // ������ ������ ������� ���� ��� ���                                                   //
                if (!string.IsNullOrWhiteSpace(sb.ToString()))                                             //
                {                                                                                          //
                                                                                                           //
                    UpdateRichTextBox("������ �ڵ�: " + hWnd.ToString() + ", ����: " + sb.ToString());
                }                                                                                          //
            }                                                                                              //
            return true;                                                                                   //
        }                                                                                                  //
                                                                                                           //
        private void button8_Click(object sender, EventArgs e)                                             //
        {                                                                                                  //
                                                                                                           //
            Console.Beep();                                                                                //
            EnumWindows(EnumWindowCallBack, IntPtr.Zero);                                                  //
        }                                                                                                  //
        //=================================================================================================//

        public class WindowNameGetter
        {
            [DllImport("user32.dll", CharSet = CharSet.Unicode)]
            private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

            [DllImport("user32.dll", SetLastError = true)]
            private static extern int GetWindowTextLength(IntPtr hWnd);

            public static string RetrieveWindowTitle(IntPtr hWnd)
            {
                int length = GetWindowTextLength(hWnd);
                if (length == 0)
                    return string.Empty;

                StringBuilder title = new StringBuilder(length + 1);
                GetWindowText(hWnd, title, title.Capacity);
                return title.ToString();
            }
        }
        private static List<IntPtr> hiddenWindowHandles = new List<IntPtr>();

        public static List<IntPtr> FindHiddenWindows()
        {
            hiddenWindowHandles.Clear();

            EnumWindows((hWnd, lParam) =>
            {
                if (!IsWindowVisible(hWnd))
                {
                    hiddenWindowHandles.Add(hWnd);
                }
                return true; // ��� ����
            }, IntPtr.Zero);

            return hiddenWindowHandles;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            List<IntPtr> hiddenWindows = FindHiddenWindows();

            foreach (IntPtr hWnd in hiddenWindows)
            {
                string windowTitle = WindowNameGetter.RetrieveWindowTitle(hWnd);
                if (windowTitle == "")
                {
                    //ShowWindow(hWnd, SW_SHOW);
                    UpdateRichTextBox($"Hidden Window Handle: {hWnd} name :{windowTitle}");
                }
            }
        }


        private void button12_Click(object sender, EventArgs e)
        {
            IPGlobalProperties properties = IPGlobalProperties.GetIPGlobalProperties();
            TcpConnectionInformation[] connections = properties.GetActiveTcpConnections();


            foreach (TcpConnectionInformation connection in connections)
            {
                //int processId = GetProcessIdFromConnection(connection); // Add this function
                if (connection.State.ToString() == "Established")
                {

                    string info = $"Local End Point: {connection.LocalEndPoint}\n";
                    info += $"Remote End Point: {connection.RemoteEndPoint}\n";
                    info += $"State: {connection.State}\n";
                    //info += $"Process ID: {processId}\n"; // Add process ID info
                    // Add more information as needed (e.g., process name)
                    UpdateRichTextBox(info); // Add newline for separation
                }
            }
        }

        private async void button17_Click(object sender, EventArgs e)
        {
            if (!IsAdministrator())
            {
                // Restart the application with administrator privileges
                //ShowAdminPrompt();
                MessageBox.Show("������ �������� ������մϴ� ���μ����� �����մϴ�.");
                RestartAsAdministrator();

                pic1process = false; pic2process = false; pic3process = false; pic4process = false;
                boollisten = false;
                boadcastbool = false;

                if ((videoSource != null && videoSource.IsRunning) || (videoSource1 != null && videoSource1.IsRunning))
                {
                    if (path != null)
                    {
                        mailsmtpnaver("enemy at the gate!! warning!!", path);
                        await Task.Delay(40);
                    }
                }
                if (server != null) { server.Stop(); }
                disposeVideoSources();

                return;
            }

            if ((button17.Text == "Server On") && (server != null))
            {
                button17.Text = "Server Off";
                boollisten = false;
                boadcastbool = false;
                server.Stop();
                richTextBox2.Text = richTextBox2.Text.Replace("listening", "OFF");
            }
            else
            {
                if (textBox13.Text != null)
                {
                    // Public IP �ּ� ���ϱ�
                    WebClient wc = new WebClient();
                    string result = wc.DownloadString("http://coreafactory.com/ip/index.php?email=" + textBox13.Text + "&port=" + textBox12.Text + "&side=server"); //Current IP Address: 119.202.146.249
                    string ip = result.Split(':')[1].Split('<')[0].Trim();

                    textBox11.Text = ip;
                    textBox12.Text = result.Split(':')[2].Split('<')[0].Trim();

                    string filePath = Path.Combine("./", "data001.json"); //Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
                    File.WriteAllText(filePath, JsonConvert.SerializeObject(textBox13.Text));

                    // �� ��ġ ����
                    var settings = new Settings
                    {
                        Location = this.Location,
                        Size = this.Size
                    };

                    string settingsJson = JsonConvert.SerializeObject(settings);
                    File.WriteAllText(filePath + ".settings", settingsJson);
                }
                boollisten = true;
                button17.Text = "Server On";

                //serverUri = "http://121.181.124.194:" + int.Parse(textBox12.Text) + "/";   //"+ textBox12.Text.ToString() + "
                int temp = int.Parse(textBox12.Text);
                string addresstemp = textBox11.Text; addresstemp = "*";
                serverUri = "http://"+ addresstemp + ":" + temp + "/";
                server = new WebSocketServer(serverUri, this);//, form1);
                boadcastbool = true;
                //Task.Run(async () =>
                //{
                server.Start(); //await 
                                //});

                //richTextBox1.AppendText("lol started \n");


                if (server != null)
                {
                    if (richTextBox2.Text.IndexOf("OFF") != -1)
                    {
                        richTextBox2.Text = richTextBox2.Text.Replace("OFF", "listening");
                    }
                    else
                    {
                        richTextBox2.AppendText("Server listening... \n");
                    }
                }
            }
        }


        //////////////////////////////////////// protect from dll injection //////////////////////////////////////////////
        public static class ProcessSecurity
        {
            private const int PROCESS_MITIGATION_POLICY_DLL_INJECTION = 0x0000000A;
            private const int PROCESS_DEP_ENABLE = 0x00000001;

            [DllImport("kernel32.dll", SetLastError = true)]
            private static extern bool SetProcessMitigationPolicy(
                int mitigationPolicy,
                IntPtr lpBuffer,
                int dwLength
            );

            [DllImport("kernel32.dll", SetLastError = true)]
            private static extern bool SetProcessDEPPolicy(
                int dwFlags
            );

            public static bool EnableDLLInjectionProtection()
            {
                // Set process mitigation policy for DLL injection protection
                PROCESS_MITIGATION_POLICY policy = new PROCESS_MITIGATION_POLICY
                {
                    Enable = 1 // Enable DLL injection protection
                };

                int size = Marshal.SizeOf(policy);
                IntPtr policyPtr = Marshal.AllocHGlobal(size);
                Marshal.StructureToPtr(policy, policyPtr, false);

                bool result = SetProcessMitigationPolicy(PROCESS_MITIGATION_POLICY_DLL_INJECTION, policyPtr, size);

                Marshal.FreeHGlobal(policyPtr);

                return result;
            }

            public static bool EnableDEP()
            {// Enable Data Execution Prevention (DEP)
                bool result = SetProcessDEPPolicy(PROCESS_DEP_ENABLE);
                if (!result)
                {
                    string errorCode = Marshal.GetLastWin32Error().ToString();
                    Console.WriteLine($"Failed to enable DEP. Error code: {errorCode}");
                }
                return result;
            }

            // Structure for PROCESS_MITIGATION_POLICY
            [StructLayout(LayoutKind.Sequential)]
            private struct PROCESS_MITIGATION_POLICY
            {
                public int Enable;
            }
        }
        //////////////////////////////////////// protect from dll injection //////////////////////////////////////////////  END

        private void button21_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            if (richTextBox1.TextLength > 120000)
            {
                richTextBox1.Text = "";
            }

            richTextBox1.ScrollToCaret();
        }


        private void button13_Click(object sender, EventArgs e)
        {


        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text == "") { textBox2.Text = "0"; }

        }

        private void preparebtn_Click(object sender, EventArgs e)
        {
            if (textBox13.Text != null)
            {
                // Public IP �ּ� ���ϱ�
                WebClient wc = new WebClient();
                string result = wc.DownloadString("http://coreafactory.com/ip/index.php?email=" + textBox13.Text + "&port=" + textBox12.Text + "&side=server"); //Current IP Address: 119.202.146.249
                string ip = result.Split(':')[1].Split('<')[0].Trim();

                textBox11.Text = ip;
                textBox12.Text = result.Split(':')[2].Split('<')[0].Trim();

                string filePath2 = Path.Combine("./", "data001.json");//Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
                File.WriteAllText(filePath2, JsonConvert.SerializeObject(textBox13.Text));

                var settings = new Settings
                {
                    Location = this.Location,
                    Size = this.Size
                };

                string settingsJson = JsonConvert.SerializeObject(settings);
                File.WriteAllText(filePath2 + ".settings", settingsJson);
            }

            //======================================================  Newtonsoft.Json  ======================================================
            textBox13.Text = "";
            string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "data001.json");
            if (File.Exists(filePath))
            {
                string id = JsonConvert.DeserializeObject<string>(File.ReadAllText(filePath));
                // Use the retrieved ID value as needed
                textBox13.Text = id;

            }
            //textBox13.Text = "pakata@korea.com";
            if (textBox12.Text != "")
            {
                textBox12.Text = "8888";
            }

            if (textBox13.Text != "")
            {
                // Public IP �ּ� ���ϱ�
                WebClient wc = new WebClient();
                string result = wc.DownloadString("http://coreafactory.com/ip/index.php?email=" + textBox13.Text + "&port=" + textBox12.Text + "&side=server"); //Current IP Address: 119.202.146.249
                string ip = result.Split(':')[1].Split('<')[0].Trim();

                textBox11.Text = ip;
                textBox12.Text = result.Split(':')[2].Split('<')[0].Trim();
            }
        }

        private void pictureBox5_LoadCompleted(object sender, AsyncCompletedEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            disposeVideoSources();
        }

        private void disposeVideoSources()
        {
            if (videoSource != null && videoSource.IsRunning)
            {
                videoSource.SignalToStop();
                videoSource.WaitForStop();
                videoSource.NewFrame -= VideoSource_NewFrame;
                videoSource = null;
            }

            if (videoSource1 != null && videoSource1.IsRunning)
            {
                videoSource1.SignalToStop();
                videoSource1.WaitForStop();
                videoSource1.NewFrame -= VideoSource_NewFrame2;
                videoSource1 = null;
            }

            deviceSeted1 = false;
            deviceSeted2 = false;
        }
        static void OpenExplorerAndNavigate(string path)
        {
            // Explorer ���μ��� ����
            Process explorerProcess = new Process();
            explorerProcess.StartInfo.FileName = "explorer.exe";

            // ������ �Ű������� ��� �߰�
            explorerProcess.StartInfo.Arguments = path;

            // Explorer ����
            explorerProcess.Start();
        }

        private void mainpicturefix_Click(object sender, EventArgs e)
        {
            Size pic5si = pictureBox5.Size; // pictureBox5�� ũ�� ��������
            Point pic5lo = pictureBox5.Location; // pictureBox5�� ��ġ ��������
            pictureBox5.MouseDown -= pictureBox5_MouseDown;
            pictureBox5.MouseMove -= pictureBox5_MouseMove; // �� PictureBox�� ���콺 �̵� �̺�Ʈ�� ������ ���� �ڵ鷯�� �����մϴ�.
            pictureBox5.MouseUp -= pictureBox5_MouseUp;


            // ���� PictureBox�� ����
            Controls.Remove(pictureBox5);
            pictureBox5.Dispose(); // PictureBox ����

            // ���ο� PictureBox ����
            System.Windows.Forms.PictureBox newPictureBox = new System.Windows.Forms.PictureBox();
            newPictureBox.Name = "pictureBox5"; // ���ο� PictureBox�� �̸� ����
            newPictureBox.Size = pic5si; // ���� PictureBox�� ũ�� ����
            newPictureBox.Location = pic5lo; // ���� PictureBox�� ��ġ ����
            newPictureBox.ImageLocation = "E:/000 USERDB/cctv/cctvcsharp/cctvcsharp/bin/Debug/net6.0-windows/������ �ǽ� ����/20_15_33_1537.jpg";
            newPictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            newPictureBox.MouseDown += pictureBox5_MouseDown; // �� PictureBox�� ���콺 �ٿ� �̺�Ʈ�� ������ ���� �ڵ鷯�� �����մϴ�.
            newPictureBox.MouseMove += pictureBox5_MouseMove; // �� PictureBox�� ���콺 �̵� �̺�Ʈ�� ������ ���� �ڵ鷯�� �����մϴ�.
            newPictureBox.MouseUp += pictureBox5_MouseUp;
            // ���ο� PictureBox�� �̹��� ����
            //newPictureBox.Image = tempbmp2; // ���÷� tempbmp2�� �̹����� ����

            // ���ο� PictureBox�� �߰�
            Controls.Add(newPictureBox);
        }

        private void mainpicrreload(Bitmap tempbmp)
        {
            if (pic5process)
            {
                pic5process = false;
                // "pictureBox5"��� �̸��� ���� PictureBox ��Ʈ�� �˻�
                Control[] foundControls = Controls.Find("pictureBox5", true);

                // �˻��� ��Ʈ���� �ϳ� �̻����� Ȯ��
                if (foundControls.Length > 0)
                {
                    // ù ��°�� �˻��� PictureBox ��Ʈ���� ������
                    System.Windows.Forms.PictureBox pictureBox5 = (System.Windows.Forms.PictureBox)foundControls[0];

                    // PictureBox�� �̹����� ����
                    pictureBox5.Image = tempbmp;
                }

                pic5process = true;
            }
        }

        private void devichk_CheckedChanged(object sender, EventArgs e)
        {

        }

        private async void camera2reset()
        {
            Console.Beep();
            await Task.Run(async () =>
            {
                if (videoSource1 != null)
                {
                    videoSource1.SignalToStop();
                    videoSource1.WaitForStop();
                    videoSource1.NewFrame -= VideoSource_NewFrame2;
                    videoSource1 = null;
                    UpdateRichTextBox("error camera2 Terminate success");
                }

                //VideoCaptureDeviceForm cameras2 = new VideoCaptureDeviceForm();
                //===================================================== camera reconect ============================================================
                if (videoDevices2[comboBox3.SelectedIndex].MonikerString != null)
                {
                    await Task.Delay(1000);

                    if (deviceSeted2)
                    {
                        await CamGetList(comboBox3);
                    }

                    await Task.Delay(3000);

                    if ((videoSource1 != null) && videoSource1.IsRunning)
                    {
                        UpdateRichTextBox("camera error recovery success");
                        await Task.Delay(10000);
                        autorecovery2.Checked = true;
                    }
                    else
                    {
                        UpdateRichTextBox("camera error recovery fail check camera device");

                        if (videoSource1 != null)
                        {
                            videoSource1.SignalToStop();
                            videoSource1.WaitForStop();
                            videoSource1.NewFrame -= VideoSource_NewFrame2;
                            videoSource1 = null;
                            UpdateRichTextBox("error camera2 Terminate success");
                        }
                    }
                }

            });
            //====================================================================================================================================
        }
        private string getpathr(string temp)
        {
            DateTime currentDate = DateTime.Today;
            day2 = currentDate.Day;
            month2 = currentDate.Month;
            year2 = currentDate.Year;

            string directoryPath = $"./{day2}_{month2}_{year2}";
            DirectoryInfo dir = new DirectoryInfo(directoryPath);

            if (!dir.Exists)
            {
                dir.Create();
            }

            DateTime currentTime = DateTime.Now;
            hour2 = currentTime.Hour;
            minute2 = currentTime.Minute;
            second2 = currentTime.Second;
            cnt++;
            string datepath;
            if (temp == "s")
            {
                datepath = $"./{day2}_{month2}_{year2}/{hour2}_{minute2}_{second2}_{cnt}_s.jpg";
            }
            else
            {
                datepath = $"./{day2}_{month2}_{year2}/{hour2}_{minute2}_{second2}_{cnt}.jpg";
            }



            return datepath;
        }

        public void UpdateRichTextBox(string message)
        {
            message = message + " " + DateTime.Now.ToString();
            if (richTextBox1.InvokeRequired)
            {
                richTextBox1.Invoke(new Action<string>(UpdateRichTextBox), message);
            }
            else
            {
                richTextBox1.AppendText(message + Environment.NewLine);
            }
        }

        public void UpdateRichTextBox1(string message)
        {
            if (richTextBox2.InvokeRequired)
            {
                richTextBox2.Invoke(new Action<string>(UpdateRichTextBox1), message);
            }
            else
            {
                string temp = message + " disconnected.";
                foreach (string line in richTextBox2.Lines)
                {
                    if (line.IndexOf(temp) != -1)
                    {
                        richTextBox2.Text = richTextBox2.Text.Replace(temp, message);
                        return;
                    }
                }

                richTextBox2.AppendText(message + Environment.NewLine);
            }
        }

        public void UpdateRichTextBox1replace(string message)
        {
            if (richTextBox2.InvokeRequired)
            {
                richTextBox2.Invoke(new Action<string>(UpdateRichTextBox1replace), message);
            }
            else
            {
                richTextBox2.Text = richTextBox2.Text.Replace(message, message + " disconnected.");
            }
        }

        private void richTextBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            richTextBox1.Text = "";
        }

        private void changeformname()
        {
            Random random = new Random();
            string temp = random.Next(10000, 99999).ToString();
            this.Name = "COREAFACTORY.COM" + temp;
            this.Text = "COREAFACTORY.COM" + temp;

            //IntPtr hWnd = FindWindow(null, "Form1");
            //UpdateRichTextBox("find form1 hwnd : " + hWnd.ToString());
        }

        //========================================================   picture zoom point selector   ============================= start

        private Point startPoint;
        private Point endPoint;
        private Rectangle selectedRectangle;
        private bool piczoomready;
        
        private void pictureBox5_MouseDown(object sender, MouseEventArgs e)
        {
            piczoomready = false;
            //UpdateRichTextBox(e.Location.ToString());
            // ���콺 ��ư�� ���� ��ġ�� ���
            startPoint = e.Location;
        }

        private void pictureBox5_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                // ���콺�� �巡�׵Ǵ� ���� ����ؼ� �巡�׵� ������ ���
                endPoint = e.Location;
            }
        }

        private void pictureBox5_MouseUp(object sender, MouseEventArgs e)
        {
            //UpdateRichTextBox(e.Location.ToString());
            // ���콺 ��ư�� ���� ��ġ�� ���
            endPoint = e.Location;

            // �巡�׵� ���� ���
            selectedRectangle = new Rectangle(
                Math.Min(startPoint.X, endPoint.X),
                Math.Min(startPoint.Y, endPoint.Y),
                Math.Abs(startPoint.X - endPoint.X),
                Math.Abs(startPoint.Y - endPoint.Y)
            );

            if (selectedRectangle.Width > 50)
            {
                // ���� ������ ����Ͽ� ���ϴ� �۾� ����
                // �� ���������� �巡�׵� ������ ���
                UpdateRichTextBox("Selected rectangle: " + selectedRectangle);
                piczoomready = true;
            }
        }

        //========================================================   picture zoom point selector   ============================= End


        // Check if the application is running with administrator privileges
        private static bool IsAdministrator()
        {
            WindowsIdentity identity = WindowsIdentity.GetCurrent();
            WindowsPrincipal principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }

        // Restart the application with administrator privileges
        private static void RestartAsAdministrator()
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.UseShellExecute = true;
            startInfo.WorkingDirectory = Environment.CurrentDirectory;
            startInfo.FileName = Application.ExecutablePath;
            startInfo.Verb = "runas"; // Run as administrator

            Screen currentScreen = Screen.FromHandle(Process.GetCurrentProcess().MainWindowHandle);
            Point newLocation = new Point(currentScreen.WorkingArea.Left, currentScreen.WorkingArea.Top);

            try
            {
                Process.Start(startInfo);
            }
            catch (System.ComponentModel.Win32Exception)
            {
                // User canceled UAC prompt
                // Do nothing or handle it as needed
            }
            //Form1.ActiveForm.Location = newLocation;

            Application.Exit();
        }
    }

    //======================================================== web socket server ===================================================  start
    public class WebSocketServer
    {
        private const int BufferSize = 1024;
        private readonly HttpListener httpListener;
        private readonly List<WebSocket> clients = new List<WebSocket>();
        public bool listeningbool;
        private readonly Form1 form1Instance;
        public bool receivebuffer;
        public bool sendingsensor;
        public WebSocketServer(string prefix, Form1 form1)
        {
            httpListener = new HttpListener();
            httpListener.Prefixes.Add(prefix);
            form1Instance = form1;
        }

        public async Task Start()
        {
            receivebuffer = true;
            sendingsensor = false;
            try
            {
                httpListener.Start();
                form1Instance.UpdateRichTextBox("Server started. Waiting for incoming connections...");
                listeningbool = true;
                while (listeningbool)
                {
                    //HttpListenerContext context = await httpListener.GetContextAsync();
                    try
                    {
                        if (httpListener != null)
                        {
                            HttpListenerContext context = await httpListener.GetContextAsync();
                            // ������ �ڵ�� context�� ����Ͽ� ó���˴ϴ�.
                            if (context.Request.IsWebSocketRequest)
                            {
                                ProcessRequest(context);
                            }
                            else
                            {
                                context.Response.StatusCode = 400;
                                context.Response.Close();
                            }
                        }
                    }
                    catch (HttpListenerException ex)
                    {
                        listeningbool = false;
                        form1Instance.UpdateRichTextBox($"Error starting server: {ex.Message}");
                        // HttpListenerException�� �߻��� ��� ó��
                        // ���� ó�� ���� �߰�
                    }
                }
            }
            catch (HttpListenerException ex)
            {
                // HttpListenerException�� �߻��� ��� ó��
                form1Instance.UpdateRichTextBox($"Error starting server: {ex.Message}");
            }
        }

        private async void ProcessRequest(HttpListenerContext context)
        {
            WebSocketContext webSocketContext = null;

            try
            {
                webSocketContext = await context.AcceptWebSocketAsync(subProtocol: null);
                form1Instance.UpdateRichTextBox("WebSocket connection established.");

                WebSocket client = webSocketContext.WebSocket;
                clients.Add(client);

                form1Instance.UpdateRichTextBox1("Client : " + context.Request.RemoteEndPoint.Address.ToString());
                form1Instance.UpdateRichTextBox("Client : " + context.Request.RemoteEndPoint.Address.ToString() + " connected ");

                form1Instance.UpdateRichTextBox(string.Concat(context.Request.Headers.GetKey(11)) + ":" +
                        string.Concat(context.Request.Headers.GetValues(11)));
                //.RemoteEndPoint.Address.ToString()); 10 ip 11 browser 12 index out
                //string.Concat(context.Request.Headers.GetValues(10))
                /*
                for (int i = 0; i < 12; i++)
                {
                    form1Instance.UpdateRichTextBox(i+":"+string.Concat(context.Request.Headers.GetKey(i))+":"+
                        string.Concat(context.Request.Headers.GetValues(i)));

                }*/
                //form1Instance.UpdateRichTextBox(string.Concat(Convert.FromBase64String(string.Concat(context.Request.Headers.GetValues(2)))));
                //form1Instance.UpdateRichTextBox(string.Concat(context.Request.RemoteEndPoint.AddressFamily.ToString()));
                await Echo(client, context.Request.RemoteEndPoint.Address.ToString());
            }
            catch (Exception ex)
            {
                context.Response.StatusCode = 500;
                context.Response.Close();
                form1Instance.UpdateRichTextBox($"WebSocket connection error: {ex.Message}");
            }
            finally
            {
                if (webSocketContext != null)
                {
                    webSocketContext.WebSocket.Dispose();
                }
            }
        }

        private async Task Echo(WebSocket client, string ipaddress)
        {
            try
            {
                byte[] buffer = new byte[BufferSize];
                WebSocketReceiveResult result = await client.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);

                while (!result.CloseStatus.HasValue)
                {
                    // Convert the received data to a string
                    string receivedData = Encoding.UTF8.GetString(buffer, 0, result.Count);

                    // Check if "eof" string is present in the received data
                    if ((receivedData.Length<20) && receivedData.Contains("eof"))
                    {
                        // If "eof" string is present, close the WebSocket connection
                        form1Instance.UpdateRichTextBox(receivedData);

                        break; // Exit the loop
                    }

                    /*
                    // Broadcast message to all connected clients
                    foreach (var otherClient in clients)
                    {
                        if (otherClient.State == WebSocketState.Open)
                        {
                            await otherClient.SendAsync(new ArraySegment<byte>(buffer, 0, result.Count), result.MessageType, result.EndOfMessage, CancellationToken.None);
                        }
                    }
                    */
                    if (receivebuffer)
                    {
                        sendingsensor = true;
                        foreach (var otherClient in clients)
                        {
                            if ((otherClient.State == WebSocketState.Open) && (tempbuffer != null))
                            {
                                await otherClient.SendAsync(new ArraySegment<byte>(tempbuffer, 0, tempbuffer.Length), WebSocketMessageType.Text, true, CancellationToken.None);
                            }
                        }

                        sendingsensor = false;
                    }
                    tempbuffer = null;

                    result = await client.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                }
            }
            catch (WebSocketException ex)
            {
                form1Instance.UpdateRichTextBox(ex.ToString());
            }

            // Ŭ���̾�Ʈ���� ���� ����� �� WebSocketException �߻�
            // ������ ����� Ŭ���̾�Ʈ�� IP �ּҸ� ǥ��
            string temp = ipaddress.Trim();
            form1Instance.UpdateRichTextBox1replace(temp);
            form1Instance.UpdateRichTextBox(temp + " disconnected ");
            // Ŭ���̾�Ʈ ���� ����
            await client.CloseAsync(WebSocketCloseStatus.NormalClosure, "", CancellationToken.None);
            clients.Remove(client);
        }

        public byte[] tempbuffer;
        // Broadcast message to all connected clients
        public async Task BroadcastMessage(byte[] buffer)
        {
            /*
            foreach (var client in clients)
            {
                if (client.State == WebSocketState.Open)
                {
                    await client.SendAsync(new ArraySegment<byte>(buffer, 0, buffer.Length), WebSocketMessageType.Text, true, CancellationToken.None);
                }
            }
            */
        }

        public async Task Stop()
        {
            listeningbool = false;
            foreach (var client in clients)
            {
                await client.CloseAsync(WebSocketCloseStatus.NormalClosure, "Server shutting down", CancellationToken.None);
            }
            httpListener.Stop();
            httpListener.Close();
        }
    }

    //======================================================== web socket server ===================================================  end


}