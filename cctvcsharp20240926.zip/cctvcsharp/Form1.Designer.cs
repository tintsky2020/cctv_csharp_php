﻿namespace cctvcsharp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            button4 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            timer2 = new System.Windows.Forms.Timer(components);
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            button5 = new Button();
            button6 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button16 = new Button();
            label5 = new Label();
            textBox5 = new TextBox();
            label6 = new Label();
            textBox6 = new TextBox();
            label7 = new Label();
            textBox7 = new TextBox();
            pictureBox5 = new PictureBox();
            label8 = new Label();
            textBox8 = new TextBox();
            label9 = new Label();
            textBox9 = new TextBox();
            label10 = new Label();
            textBox10 = new TextBox();
            richTextBox1 = new RichTextBox();
            button17 = new Button();
            button18 = new Button();
            textBox11 = new TextBox();
            textBox12 = new TextBox();
            button19 = new Button();
            button20 = new Button();
            label11 = new Label();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            button21 = new Button();
            richTextBox2 = new RichTextBox();
            textBox13 = new TextBox();
            label12 = new Label();
            label13 = new Label();
            checksave = new CheckBox();
            cctv1 = new RadioButton();
            cctv2 = new RadioButton();
            cctv3 = new RadioButton();
            cctv4 = new RadioButton();
            checkbeep = new CheckBox();
            chase1 = new RadioButton();
            chase2 = new RadioButton();
            chase3 = new RadioButton();
            chase4 = new RadioButton();
            preparebtn = new Button();
            sensorcheck = new CheckBox();
            button3 = new Button();
            devichk = new CheckBox();
            mainpicturefix = new Button();
            autorecovery2 = new CheckBox();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            comboBox3 = new ComboBox();
            comboBox4 = new ComboBox();
            previewcheck1 = new CheckBox();
            previewcheck2 = new CheckBox();
            previewcheckMain = new CheckBox();
            TcpSend2 = new CheckBox();
            TcpSend1 = new CheckBox();
            sense1 = new CheckBox();
            sense2 = new CheckBox();
            information = new CheckBox();
            randomname = new CheckBox();
            infoconnection = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 41);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(285, 226);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.LoadCompleted += pictureBox1_LoadCompleted;
            // 
            // button1
            // 
            button1.Location = new Point(2, 302);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(83, 302);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 2;
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(75, 12);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(61, 23);
            textBox1.TabIndex = 3;
            textBox1.Text = "3";
            textBox1.MouseClick += textBox1_MouseClick;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(217, 12);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(61, 23);
            textBox2.TabIndex = 4;
            textBox2.Text = "0.001";
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(222, 302);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(66, 23);
            textBox3.TabIndex = 5;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(222, 331);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(66, 23);
            textBox4.TabIndex = 6;
            // 
            // button4
            // 
            button4.Location = new Point(83, 331);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 8;
            button4.Text = "button4";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(3, 15);
            label1.Name = "label1";
            label1.Size = new Size(51, 15);
            label1.TabIndex = 9;
            label1.Text = "wish fps";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(145, 15);
            label2.Name = "label2";
            label2.Size = new Size(25, 15);
            label2.TabIndex = 10;
            label2.Text = "diff";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(177, 306);
            label3.Name = "label3";
            label3.Size = new Size(23, 15);
            label3.TabIndex = 11;
            label3.Text = "fps";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(177, 335);
            label4.Name = "label4";
            label4.Size = new Size(27, 15);
            label4.TabIndex = 12;
            label4.Text = "size";
            // 
            // timer1
            // 
            timer1.Interval = 20;
            timer1.Tick += timer1_Tick;
            // 
            // timer2
            // 
            timer2.Interval = 1000;
            timer2.Tick += timer2_Tick;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(294, 41);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(285, 226);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 13;
            pictureBox2.TabStop = false;
            pictureBox2.WaitOnLoad = true;
            // 
            // pictureBox3
            // 
            pictureBox3.Location = new Point(2, 379);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(285, 226);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 14;
            pictureBox3.TabStop = false;
            pictureBox3.WaitOnLoad = true;
            // 
            // pictureBox4
            // 
            pictureBox4.Location = new Point(294, 379);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(285, 226);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 15;
            pictureBox4.TabStop = false;
            pictureBox4.WaitOnLoad = true;
            // 
            // button5
            // 
            button5.Location = new Point(294, 302);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 16;
            button5.Text = "button5";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(375, 302);
            button6.Name = "button6";
            button6.Size = new Size(75, 23);
            button6.TabIndex = 17;
            button6.Text = "button6";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button8
            // 
            button8.Location = new Point(375, 330);
            button8.Name = "button8";
            button8.Size = new Size(75, 23);
            button8.TabIndex = 19;
            button8.Text = "windowlist";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(3, 611);
            button9.Name = "button9";
            button9.Size = new Size(75, 23);
            button9.TabIndex = 23;
            button9.Text = "hidewindow";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(83, 611);
            button10.Name = "button10";
            button10.Size = new Size(75, 23);
            button10.TabIndex = 22;
            button10.Text = "showhidden";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button12
            // 
            button12.Location = new Point(83, 640);
            button12.Name = "button12";
            button12.Size = new Size(75, 23);
            button12.TabIndex = 20;
            button12.Text = "opensocket";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // button13
            // 
            button13.Location = new Point(294, 611);
            button13.Name = "button13";
            button13.Size = new Size(75, 23);
            button13.TabIndex = 27;
            button13.Text = "button13";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.Location = new Point(374, 611);
            button14.Name = "button14";
            button14.Size = new Size(75, 23);
            button14.TabIndex = 26;
            button14.Text = "button14";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button14_Click;
            // 
            // button16
            // 
            button16.Location = new Point(374, 640);
            button16.Name = "button16";
            button16.Size = new Size(75, 23);
            button16.TabIndex = 24;
            button16.Text = "button16";
            button16.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(467, 335);
            label5.Name = "label5";
            label5.Size = new Size(27, 15);
            label5.TabIndex = 29;
            label5.Text = "size";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(512, 331);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(66, 23);
            textBox5.TabIndex = 28;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(176, 644);
            label6.Name = "label6";
            label6.Size = new Size(27, 15);
            label6.TabIndex = 31;
            label6.Text = "size";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(221, 640);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(66, 23);
            textBox6.TabIndex = 30;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(467, 644);
            label7.Name = "label7";
            label7.Size = new Size(27, 15);
            label7.TabIndex = 33;
            label7.Text = "size";
            // 
            // textBox7
            // 
            textBox7.Location = new Point(512, 640);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(66, 23);
            textBox7.TabIndex = 32;
            // 
            // pictureBox5
            // 
            pictureBox5.Location = new Point(585, 41);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(1297, 954);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 34;
            pictureBox5.TabStop = false;
            pictureBox5.WaitOnLoad = true;
            pictureBox5.LoadCompleted += pictureBox5_LoadCompleted;
            pictureBox5.MouseDown += pictureBox5_MouseDown;
            pictureBox5.MouseMove += pictureBox5_MouseMove;
            pictureBox5.MouseUp += pictureBox5_MouseUp;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(468, 307);
            label8.Name = "label8";
            label8.Size = new Size(23, 15);
            label8.TabIndex = 36;
            label8.Text = "fps";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(512, 303);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(66, 23);
            textBox8.TabIndex = 35;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(176, 615);
            label9.Name = "label9";
            label9.Size = new Size(23, 15);
            label9.TabIndex = 38;
            label9.Text = "fps";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(221, 611);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(66, 23);
            textBox9.TabIndex = 37;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(468, 616);
            label10.Name = "label10";
            label10.Size = new Size(23, 15);
            label10.TabIndex = 40;
            label10.Text = "fps";
            // 
            // textBox10
            // 
            textBox10.Location = new Point(512, 612);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(66, 23);
            textBox10.TabIndex = 39;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(2, 687);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(387, 307);
            richTextBox1.TabIndex = 41;
            richTextBox1.Text = "";
            richTextBox1.TextChanged += richTextBox1_TextChanged;
            richTextBox1.MouseDoubleClick += richTextBox1_MouseDoubleClick;
            // 
            // button17
            // 
            button17.Location = new Point(972, 11);
            button17.Name = "button17";
            button17.Size = new Size(75, 23);
            button17.TabIndex = 42;
            button17.Text = "Host";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // button18
            // 
            button18.Location = new Point(1053, 11);
            button18.Name = "button18";
            button18.Size = new Size(75, 23);
            button18.TabIndex = 43;
            button18.Text = "safe close";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(431, 12);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(126, 23);
            textBox11.TabIndex = 44;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(563, 12);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(71, 23);
            textBox12.TabIndex = 45;
            // 
            // button19
            // 
            button19.Location = new Point(891, 11);
            button19.Name = "button19";
            button19.Size = new Size(75, 23);
            button19.TabIndex = 46;
            button19.Text = "Folder";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // button20
            // 
            button20.Location = new Point(729, 12);
            button20.Name = "button20";
            button20.Size = new Size(75, 23);
            button20.TabIndex = 47;
            button20.Text = "st1 extract";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(12, 669);
            label11.Name = "label11";
            label11.Size = new Size(316, 15);
            label11.TabIndex = 48;
            label11.Text = "This program is free software GNU General Public License";
            // 
            // button21
            // 
            button21.Location = new Point(810, 11);
            button21.Name = "button21";
            button21.Size = new Size(75, 23);
            button21.TabIndex = 49;
            button21.Text = "webHost";
            button21.UseVisualStyleBackColor = true;
            button21.Click += button21_Click;
            // 
            // richTextBox2
            // 
            richTextBox2.Location = new Point(395, 687);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.Size = new Size(184, 307);
            richTextBox2.TabIndex = 50;
            richTextBox2.Text = "";
            // 
            // textBox13
            // 
            textBox13.Location = new Point(294, 12);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(131, 23);
            textBox13.TabIndex = 51;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(304, 238);
            label12.Name = "label12";
            label12.Size = new Size(46, 15);
            label12.TabIndex = 52;
            label12.Text = "label12";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(8, 238);
            label13.Name = "label13";
            label13.Size = new Size(46, 15);
            label13.TabIndex = 52;
            label13.Text = "label13";
            // 
            // checksave
            // 
            checksave.AutoSize = true;
            checksave.Location = new Point(1189, 0);
            checksave.Name = "checksave";
            checksave.Size = new Size(69, 19);
            checksave.TabIndex = 54;
            checksave.Text = "SaveFile";
            checksave.TextAlign = ContentAlignment.MiddleCenter;
            checksave.UseVisualStyleBackColor = true;
            // 
            // cctv1
            // 
            cctv1.AutoSize = true;
            cctv1.Location = new Point(1264, 0);
            cctv1.Name = "cctv1";
            cctv1.Size = new Size(54, 19);
            cctv1.TabIndex = 55;
            cctv1.TabStop = true;
            cctv1.Text = "cctv1";
            cctv1.UseVisualStyleBackColor = true;
            // 
            // cctv2
            // 
            cctv2.AutoSize = true;
            cctv2.Location = new Point(1324, 0);
            cctv2.Name = "cctv2";
            cctv2.Size = new Size(54, 19);
            cctv2.TabIndex = 56;
            cctv2.TabStop = true;
            cctv2.Text = "cctv2";
            cctv2.UseVisualStyleBackColor = true;
            // 
            // cctv3
            // 
            cctv3.AutoSize = true;
            cctv3.Location = new Point(1384, 0);
            cctv3.Name = "cctv3";
            cctv3.Size = new Size(54, 19);
            cctv3.TabIndex = 57;
            cctv3.TabStop = true;
            cctv3.Text = "cctv3";
            cctv3.UseVisualStyleBackColor = true;
            // 
            // cctv4
            // 
            cctv4.AutoSize = true;
            cctv4.Location = new Point(1444, 0);
            cctv4.Name = "cctv4";
            cctv4.Size = new Size(54, 19);
            cctv4.TabIndex = 58;
            cctv4.TabStop = true;
            cctv4.Text = "cctv4";
            cctv4.UseVisualStyleBackColor = true;
            // 
            // checkbeep
            // 
            checkbeep.AutoSize = true;
            checkbeep.Location = new Point(1141, 0);
            checkbeep.Name = "checkbeep";
            checkbeep.Size = new Size(52, 19);
            checkbeep.TabIndex = 53;
            checkbeep.Text = "beep";
            checkbeep.UseVisualStyleBackColor = true;
            // 
            // chase1
            // 
            chase1.AutoSize = true;
            chase1.Location = new Point(1264, 21);
            chase1.Name = "chase1";
            chase1.Size = new Size(62, 19);
            chase1.TabIndex = 55;
            chase1.TabStop = true;
            chase1.Text = "chase1";
            chase1.UseVisualStyleBackColor = true;
            // 
            // chase2
            // 
            chase2.AutoSize = true;
            chase2.Location = new Point(1324, 21);
            chase2.Name = "chase2";
            chase2.Size = new Size(62, 19);
            chase2.TabIndex = 56;
            chase2.TabStop = true;
            chase2.Text = "chase2";
            chase2.UseVisualStyleBackColor = true;
            // 
            // chase3
            // 
            chase3.AutoSize = true;
            chase3.Location = new Point(1384, 21);
            chase3.Name = "chase3";
            chase3.Size = new Size(62, 19);
            chase3.TabIndex = 57;
            chase3.TabStop = true;
            chase3.Text = "chase3";
            chase3.UseVisualStyleBackColor = true;
            // 
            // chase4
            // 
            chase4.AutoSize = true;
            chase4.Location = new Point(1444, 21);
            chase4.Name = "chase4";
            chase4.Size = new Size(62, 19);
            chase4.TabIndex = 58;
            chase4.TabStop = true;
            chase4.Text = "chase4";
            chase4.UseVisualStyleBackColor = true;
            // 
            // preparebtn
            // 
            preparebtn.Location = new Point(640, 12);
            preparebtn.Name = "preparebtn";
            preparebtn.Size = new Size(75, 23);
            preparebtn.TabIndex = 59;
            preparebtn.Text = "email chg";
            preparebtn.UseVisualStyleBackColor = true;
            preparebtn.Click += preparebtn_Click;
            // 
            // sensorcheck
            // 
            sensorcheck.AutoSize = true;
            sensorcheck.Location = new Point(1141, 21);
            sensorcheck.Name = "sensorcheck";
            sensorcheck.Size = new Size(59, 19);
            sensorcheck.TabIndex = 61;
            sensorcheck.Text = "senser";
            sensorcheck.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(294, 330);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 62;
            button3.Text = "deviceck";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // devichk
            // 
            devichk.AutoSize = true;
            devichk.Location = new Point(1189, 21);
            devichk.Name = "devichk";
            devichk.Size = new Size(67, 19);
            devichk.TabIndex = 63;
            devichk.Text = "devichk";
            devichk.UseVisualStyleBackColor = true;
            devichk.CheckedChanged += devichk_CheckedChanged;
            // 
            // mainpicturefix
            // 
            mainpicturefix.Location = new Point(3, 331);
            mainpicturefix.Name = "mainpicturefix";
            mainpicturefix.Size = new Size(75, 23);
            mainpicturefix.TabIndex = 64;
            mainpicturefix.Text = "mainpicturefix";
            mainpicturefix.UseVisualStyleBackColor = true;
            mainpicturefix.Click += mainpicturefix_Click;
            // 
            // autorecovery2
            // 
            autorecovery2.AutoSize = true;
            autorecovery2.Checked = true;
            autorecovery2.CheckState = CheckState.Checked;
            autorecovery2.Location = new Point(472, 248);
            autorecovery2.Name = "autorecovery2";
            autorecovery2.Size = new Size(102, 19);
            autorecovery2.TabIndex = 65;
            autorecovery2.Text = "autorecovery2";
            autorecovery2.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(3, 273);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(140, 23);
            comboBox1.TabIndex = 66;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(148, 273);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(140, 23);
            comboBox2.TabIndex = 67;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(294, 273);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(140, 23);
            comboBox3.TabIndex = 68;
            comboBox3.SelectedIndexChanged += comboBox3_SelectedIndexChanged;
            // 
            // comboBox4
            // 
            comboBox4.FormattingEnabled = true;
            comboBox4.Location = new Point(439, 273);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(140, 23);
            comboBox4.TabIndex = 69;
            comboBox4.SelectedIndexChanged += comboBox4_SelectedIndexChanged;
            // 
            // previewcheck1
            // 
            previewcheck1.AutoSize = true;
            previewcheck1.Checked = true;
            previewcheck1.CheckState = CheckState.Checked;
            previewcheck1.Location = new Point(177, 223);
            previewcheck1.Name = "previewcheck1";
            previewcheck1.Size = new Size(105, 19);
            previewcheck1.TabIndex = 70;
            previewcheck1.Text = "previewcheck1";
            previewcheck1.UseVisualStyleBackColor = true;
            // 
            // previewcheck2
            // 
            previewcheck2.AutoSize = true;
            previewcheck2.Checked = true;
            previewcheck2.CheckState = CheckState.Checked;
            previewcheck2.Location = new Point(472, 223);
            previewcheck2.Name = "previewcheck2";
            previewcheck2.Size = new Size(105, 19);
            previewcheck2.TabIndex = 71;
            previewcheck2.Text = "previewcheck2";
            previewcheck2.UseVisualStyleBackColor = true;
            // 
            // previewcheckMain
            // 
            previewcheckMain.AutoSize = true;
            previewcheckMain.Checked = true;
            previewcheckMain.CheckState = CheckState.Checked;
            previewcheckMain.Location = new Point(585, 41);
            previewcheckMain.Name = "previewcheckMain";
            previewcheckMain.Size = new Size(125, 19);
            previewcheckMain.TabIndex = 72;
            previewcheckMain.Text = "previewcheckMain";
            previewcheckMain.UseVisualStyleBackColor = true;
            // 
            // TcpSend2
            // 
            TcpSend2.AutoSize = true;
            TcpSend2.Checked = true;
            TcpSend2.CheckState = CheckState.Checked;
            TcpSend2.Location = new Point(472, 198);
            TcpSend2.Name = "TcpSend2";
            TcpSend2.Size = new Size(79, 19);
            TcpSend2.TabIndex = 73;
            TcpSend2.Text = "TcpSend2";
            TcpSend2.UseVisualStyleBackColor = true;
            // 
            // TcpSend1
            // 
            TcpSend1.AutoSize = true;
            TcpSend1.Checked = true;
            TcpSend1.CheckState = CheckState.Checked;
            TcpSend1.Location = new Point(177, 198);
            TcpSend1.Name = "TcpSend1";
            TcpSend1.Size = new Size(79, 19);
            TcpSend1.TabIndex = 74;
            TcpSend1.Text = "TcpSend1";
            TcpSend1.UseVisualStyleBackColor = true;
            // 
            // sense1
            // 
            sense1.AutoSize = true;
            sense1.Checked = true;
            sense1.CheckState = CheckState.Checked;
            sense1.Location = new Point(177, 173);
            sense1.Name = "sense1";
            sense1.Size = new Size(62, 19);
            sense1.TabIndex = 75;
            sense1.Text = "sense1";
            sense1.UseVisualStyleBackColor = true;
            // 
            // sense2
            // 
            sense2.AutoSize = true;
            sense2.Checked = true;
            sense2.CheckState = CheckState.Checked;
            sense2.Location = new Point(472, 173);
            sense2.Name = "sense2";
            sense2.Size = new Size(62, 19);
            sense2.TabIndex = 76;
            sense2.Text = "sense2";
            sense2.UseVisualStyleBackColor = true;
            // 
            // information
            // 
            information.AutoSize = true;
            information.Checked = true;
            information.CheckState = CheckState.Checked;
            information.Location = new Point(585, 66);
            information.Name = "information";
            information.Size = new Size(89, 19);
            information.TabIndex = 77;
            information.Text = "information";
            information.UseVisualStyleBackColor = true;
            // 
            // randomname
            // 
            randomname.AutoSize = true;
            randomname.Location = new Point(1512, 1);
            randomname.Name = "randomname";
            randomname.Size = new Size(98, 19);
            randomname.TabIndex = 78;
            randomname.Text = "randomname";
            randomname.UseVisualStyleBackColor = true;
            // 
            // infoconnection
            // 
            infoconnection.AutoSize = true;
            infoconnection.Checked = true;
            infoconnection.CheckState = CheckState.Checked;
            infoconnection.Location = new Point(585, 91);
            infoconnection.Name = "infoconnection";
            infoconnection.Size = new Size(107, 19);
            infoconnection.TabIndex = 79;
            infoconnection.Text = "infoconnection";
            infoconnection.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1894, 1001);
            Controls.Add(infoconnection);
            Controls.Add(randomname);
            Controls.Add(information);
            Controls.Add(sense2);
            Controls.Add(sense1);
            Controls.Add(TcpSend1);
            Controls.Add(TcpSend2);
            Controls.Add(previewcheckMain);
            Controls.Add(previewcheck2);
            Controls.Add(previewcheck1);
            Controls.Add(comboBox4);
            Controls.Add(comboBox3);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(autorecovery2);
            Controls.Add(mainpicturefix);
            Controls.Add(devichk);
            Controls.Add(button3);
            Controls.Add(sensorcheck);
            Controls.Add(preparebtn);
            Controls.Add(chase4);
            Controls.Add(cctv4);
            Controls.Add(chase3);
            Controls.Add(cctv3);
            Controls.Add(chase2);
            Controls.Add(chase1);
            Controls.Add(cctv2);
            Controls.Add(cctv1);
            Controls.Add(checksave);
            Controls.Add(checkbeep);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(textBox13);
            Controls.Add(richTextBox2);
            Controls.Add(button21);
            Controls.Add(label11);
            Controls.Add(button20);
            Controls.Add(button19);
            Controls.Add(textBox12);
            Controls.Add(textBox11);
            Controls.Add(button18);
            Controls.Add(button17);
            Controls.Add(richTextBox1);
            Controls.Add(label10);
            Controls.Add(textBox10);
            Controls.Add(label9);
            Controls.Add(textBox9);
            Controls.Add(label8);
            Controls.Add(textBox8);
            Controls.Add(pictureBox5);
            Controls.Add(label7);
            Controls.Add(textBox7);
            Controls.Add(label6);
            Controls.Add(textBox6);
            Controls.Add(label5);
            Controls.Add(textBox5);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button16);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button12);
            Controls.Add(button8);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button4);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterParent;
            Text = "COREAFACTORY.COM";
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Button button1;
        private Button button2;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Button button4;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private Button button5;
        private Button button6;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button16;
        private Label label5;
        private TextBox textBox5;
        private Label label6;
        private TextBox textBox6;
        private Label label7;
        private TextBox textBox7;
        private PictureBox pictureBox5;
        private Label label8;
        private TextBox textBox8;
        private Label label9;
        private TextBox textBox9;
        private Label label10;
        private TextBox textBox10;
        private RichTextBox richTextBox1;
        private Button button17;
        private Button button18;
        private TextBox textBox11;
        private TextBox textBox12;
        private Button button19;
        private Button button20;
        private Label label11;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private Button button21;
        private RichTextBox richTextBox2;
        private TextBox textBox13;
        private Label label12;
        private Label label13;
        private CheckBox checksave;
        private RadioButton cctv1;
        private RadioButton cctv2;
        private RadioButton cctv3;
        private RadioButton cctv4;
        private CheckBox checkbeep;
        private RadioButton chase1;
        private RadioButton chase2;
        private RadioButton chase3;
        private RadioButton chase4;
        private Button preparebtn;
        private CheckBox sensorcheck;
        private Button button3;
        private CheckBox devichk;
        private Button mainpicturefix;
        private CheckBox autorecovery2;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private ComboBox comboBox3;
        private ComboBox comboBox4;
        private CheckBox previewcheck1;
        private CheckBox previewcheck2;
        private CheckBox previewcheckMain;
        private CheckBox TcpSend2;
        private CheckBox TcpSend1;
        private CheckBox sense1;
        private CheckBox sense2;
        private CheckBox information;
        private CheckBox randomname;
        private CheckBox infoconnection;
    }
}