<?php

// Check the current URL
$currentURL = $_SERVER['REQUEST_URI'];

echo $currentURL+"____";
echo "<a href='http://coreafactory.com/cctv'>CCTV FIX CONNECTION</a><br>";
/*
// Compare the current URL
if (strcmp($currentURL, 'http://coreafactory.com/cctv') !== 0) {
    // Current URL is not the desired one, redirect
    header('Location: http://coreafactory.com/cctv');
    exit(); // Stop further execution of the script
}
*/
// Continue normal execution if the URL is already correct
// ... Your website content or code ...

?>

<!DOCTYPE html>
<html>
<head>
    <title>WebSocket Text Streaming</title>


</head>
<body>

<button onclick="connectWebSocketbtn()">Connect WebSocket</button>
    <button onclick="disconnectWebSocket()">Disconnect WebSocket</button>
	<button onclick="requestWebSocket()">Request WebSocket</button>
    <input type="text" id="ipAddress" value="61.80.245.20">
    <input type="text" id="portNumber" value="8888">
    <div id="textContainer" width="500" height="500" border="1">textcontainer</div>
    <input type="number" id="imageWidth" value="640">  
	<input type="number" id="imageHeight" value="480"> 
	<select id="imageSize" onchange="updateImageSize()">
		<option value="original">원본 크기</option>
		<option value="double">두 배 크기</option>
		<option value="custom" selected>사용자 정의</option>
		<option value="apple">애플가로크기</option>
	</select>
	<select id="selectcctv" onchange="selectcctv()">
		<option value="1">1번cctv</option>
		<option value="2">2번cctv</option>
		<option value="3" selected>둘다</option>
	</select>

	<script>
			let socket;
			let textContainer;
			let running="1";
			let zindexcount=1;
			let imgElements = [];
			let lastTextContent = '';
			let intervalId;

		function connectWebSocket() {
			var imageData = "";
			var marker1 = btoa("efig1");
			var marker2 = btoa("efig2");
			var ResolutionStringEnd = btoa("|ef");
			var ipAddress = document.getElementById("ipAddress").value;
			var portNumber = document.getElementById("portNumber").value;
			var count=0;
			var receiving=true;

			// 입력한 아이피 주소와 포트 번호를 WebSocket 주소에 적용
			var webSocketUrl = "ws://" + ipAddress + ":" + portNumber;
			textContainer = document.getElementById("textContainer");
			textContainer.innerText = "\nWebSocket connecting try...\n"; // 텍스트 업데이트


			socket = new WebSocket(webSocketUrl); // 서버 주소와 포트 번호를 적절히 변경하세요 61.80.245.20


			socket.onopen = function() {
				textContainer.innerText = "\nWebSocket connected:\n"; // 텍스트 업데이트
				setTimeout(() => {socket.send("firstmsg");}, 500);
			};

			socket.onclose = function(event) {
				textContainer.innerText = "\nWebSocket disconnected:"+event.reason+ receiving+"\n"; // 텍스트 업데이트
				socket.send("eof");
				//socket.close();
				//if(running!=="2"){
				//	setTimeout(() => {connectWebSocket();}, 1000);
				//}
			};

			socket.onmessage = function(event) {
				if(!receiving){
					return;
				}
				receiving=false;
				const cctvselecte = document.getElementById("selectcctv").value;
				var cctv1="1";
				var cctv2="1";
				if(cctvselecte==="1"){
					cctv1="1";
					cctv2="2";
				}else if(cctvselecte==="2"){
					cctv1="2";
					cctv2="1";
				}else if(cctvselecte==="3"){
					cctv1="1";
					cctv2="1";
				}

				// Get user input for image size
				var imageWidth = document.getElementById("imageWidth").value;
				var imageHeight = document.getElementById("imageHeight").value;
				// Update CCTV div size based on user input
				document.getElementById("cctvp").style.width = imageWidth + "px";
				document.getElementById("cctvp").style.height = imageHeight + "px";
				document.getElementById("cctv1").style.width = imageWidth + "px";
				document.getElementById("cctv1").style.height = imageHeight + "px";

				const textData=event.data;
				var positionE = textData.indexOf(ResolutionStringEnd);

				if((positionE !== -1 )&& (positionE<textData.length)){
					imageData += textData.substring(0, positionE);
					var position1 = imageData.indexOf(marker1);
					var position2 = imageData.indexOf(marker2);
				
					if (position1 !== -1) {

						let resolutionString;
						try{
							const resolutionTemp=imageData.substring(position1+marker1.length);
							resolutionString = new TextDecoder().decode(base64ToUint8Array(resolutionTemp));
						}catch(error){
							setTimeout(() => {socket.send("success1");}, 500);
							textContainer.innerText=error;
							return;
						}

						setResolution(resolutionString);

						if(cctv1==="1"){
							imageData=imageData.substring(0, position1);

							var imageUrl = 'data:image/jpeg;base64,' + imageData;
							let blobUrl;
							try{
								const blob = new Blob([base64ToUint8Array(imageData)], { type: 'image/jpeg' });
								blobUrl = URL.createObjectURL(blob);
							} catch (error) {
								setTimeout(() => {socket.send("success1");}, 500);
								textContainer.innerText=error;
								return;
							}

							if(zindexcount>2){
								zindexcount=1;
							}

							// 새로운 이미지만 추가
							const imgElement = document.createElement('img');
							imgElement.width = imageWidth;
							imgElement.height = imageHeight;
							imgElement.src = blobUrl;
							imgElement.style.position = 'absolute';
							imgElement.style.top = '0';
							imgElement.style.left = '0';
							imgElement.style.zIndex = zindexcount.toString();

							// 이미지 엘리먼트 배열에 추가
							imgElements.push(imgElement);

							document.getElementById('cctv1').appendChild(imgElement);

							if (imgElements.length > 3) {
								const oldImgElement = imgElements.shift()
								document.getElementById('cctv1').removeChild(oldImgElement);
							}

							//document.getElementById('cctv1').innerHTML += '<img width="' + imageWidth + '" height="' + imageHeight + '" src="' + blobUrl + '" style="position: absolute;top: 0;left: 0;z-index:' + zindexcount + '"/>';
							zindexcount+=1;
							//'<img width="1900" height="1000" src="' + blobUrl + '" />';
							setTimeout(() => {URL.revokeObjectURL(blobUrl);}, 1000); // 1초 후 실행
						}
						count++;
						setTimeout(() => {socket.send("success1");}, 500);
						imageData = textData.substring(positionE + ResolutionStringEnd.length);


					}else if(position2 !== -1) {
						let resolutionString;
						try{
							const resolutionTemp=imageData.substring(position2+marker2.length);
							resolutionString = new TextDecoder().decode(base64ToUint8Array(resolutionTemp));
						}catch(error){
							setTimeout(() => {socket.send("success1");}, 500);
							textContainer.innerText=error;
							return;
						}
						

						setResolution(resolutionString);

						if(cctv2==="1"){
							imageData=imageData.substring(0, position2);

							var imageUrl = 'data:image/jpeg;base64,' + imageData;
							let blobUrl;
							try{
								const blob = new Blob([base64ToUint8Array(imageData)], { type: 'image/jpeg' });
								blobUrl = URL.createObjectURL(blob);
							} catch (error) {
								setTimeout(() => {socket.send("success1");}, 500);
								textContainer.innerText=error;
								return;
							}

							if(zindexcount>2){
								zindexcount=1;
							}

							// 새로운 이미지만 추가
							const imgElement = document.createElement('img');
							imgElement.width = imageWidth;
							imgElement.height = imageHeight;
							imgElement.src = blobUrl;
							imgElement.style.position = 'absolute';
							imgElement.style.top = '0';
							imgElement.style.left = '0';
							imgElement.style.zIndex = zindexcount.toString();

							// 이미지 엘리먼트 배열에 추가
							imgElements.push(imgElement);

							document.getElementById('cctv1').appendChild(imgElement);

							if (imgElements.length > 3) {
								const oldImgElement = imgElements.shift()
								document.getElementById('cctv1').removeChild(oldImgElement);
							}

							//setTimeout(() => {URL.revokeObjectURL(blobUrl);}, 1000); // 1초 후 실행

							//document.getElementById('cctv1').innerHTML += '<img width="' + imageWidth + '" height="' + imageHeight + '" src="' + blobUrl + '" style="position: absolute;top: 0;left: 0;z-index:' + zindexcount + '"/>';
							zindexcount+=1;
							//'<img width="1900" height="1000" src="' + blobUrl + '" />';
							
						}
						count++;
						setTimeout(() => {socket.send("success1");}, 500);
						imageData = textData.substring(positionE + ResolutionStringEnd.length);
						textContainer.innerText ="7";
					}
				}else{
					
					imageData += textData;
				}
				
				textContainer.innerText=event.data.length+" : "+count+" - "+cctv1;
	 			// Update the appropriate CCTV div based on the received data
				//textContainer.innerHTML += marker2.length + "<br>"; // 텍스트 업데이트
				receiving=true;
				//lastTextContent = count;
				
			};

			socket.onerror = function(error) {
				textContainer.innerText = "WebSocket error: ";//, error;
			};

			
			intervalId = setInterval(() => {
				if ((count === lastTextContent) && (running!=="2")) {  //

					textContainer.innerText="setinterval processed";
					socket.send("success1");
					//socket.close();
					//setTimeout(() => {connectWebSocket();}, 1000);
				}else {
					lastTextContent = count; // 텍스트 내용이 변경되면 lastTextContent 업데이트
				}
			}, 3000);
			
		}

		function requestWebSocket(){
			socket.send("success1");
		}

		function disconnectWebSocket() {
			clearInterval(intervalId);
			running="2";
			socket.send("eof");
            if (socket) {
            	socket.close();
			}
        }

		function connectWebSocketbtn(){
			running="1";
			connectWebSocket();
		}

        window.addEventListener("beforeunload", function(event) {
            disconnectWebSocket();
        });

		// Base64 to Uint8Array 변환 함수
		function base64ToUint8Array(base64) {
			try{
			  const binaryString = atob(base64);
			  const len = binaryString.length;
			  const bytes = new Uint8Array(len);
			  for (let i = 0; i < len; i++) {
				bytes[i] = binaryString.charCodeAt(i);
			  }

			  return bytes;
			  }catch(error){
				  textContainer.innerText+=error;
				  return false;
			  }
		}

		function setResolution(resolutionString){

			const selectedOption = document.getElementById("imageSize").value;
			// Split the resolution string and parse values with error handling
			const [widthString, heightString] = resolutionString.split('x');
			const imageWidth = parseInt(widthString);
			const imageHeight = parseInt(heightString);

			// Handle potential errors during parsing
			if (isNaN(imageWidth) || isNaN(imageHeight)) {
				console.error("Invalid resolution string format:", resolutionString);
				// Handle the error appropriately, e.g., set default values or display a message
			} else {
				if (selectedOption === "original") {
					document.getElementById("imageWidth").value = imageWidth;
					document.getElementById("imageHeight").value = imageHeight;
				} else if (selectedOption === "double") {
					document.getElementById("imageWidth").value = imageWidth*2;
					document.getElementById("imageHeight").value = imageHeight*2;
				}else if(selectedOption === "apple"){
					document.getElementById("imageWidth").value = 1250;
					document.getElementById("imageHeight").value = 768;
				}else{

				}
			}

		}

    </script>

<div id="cctvp" style="width:640px;height:480px;border:1px solid #000000;position:relative;display:block;">
    <div id="cctv1" style="width:640px;height:480px;border:1px solid #000000;position:relative;display:block;float:left;"><p>temp</p></div>
</div>


<?php
echo "<br>UNDERCONSTRUCTION !!!<br><br>";
echo "<a href=cctvcsharp.exe>download PC server</a><br><br><br>";
echo "<a href=https://github.com/tintsky2020>https://github.com/tintsky2020</a><br><br>";
?>

<button onclick="getLocation()">Get Location</button>
    <p id="demo"></p>

    <script>

        function getLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showPosition, showError);
            } else {
                document.getElementById("demo").innerHTML = "Geolocation is not supported by this browser.";
            }
        }

        function showPosition(position) {
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;
            document.getElementById("demo").innerHTML = "Latitude: " + latitude + "<br>Longitude: " + longitude;
// 네이버 API 키
const NAVER_CLIENT_ID = 'XnJ3Ii1tUFYZrYl3OmZ8';
const NAVER_CLIENT_SECRET = 'MGOVFrxRgF';
// 네이버 지도 API 호출
fetch(`https://openapi.naver.com/v1/map/geocode.json?lat=${Latitude}&lng=${longitude}&query={Latitude},{longitude}&clientId=${NAVER_CLIENT_ID}&clientSecret=${NAVER_CLIENT_SECRET}`)
  .then(response => response.json())
  .then(data => {
    const location = data.result.address;
    document.getElementById("demo").innerHTML+=location;
  })
  .catch(error => document.getElementById("demo").innerHTML+=error);

        }

        function showError(error) {
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    document.getElementById("demo").innerHTML = "User denied the request for Geolocation.";
                    break;
                case error.POSITION_UNAVAILABLE:
                    document.getElementById("demo").innerHTML = "Location information is unavailable.";
                    break;
                case error.TIMEOUT:
                    document.getElementById("demo").innerHTML = "The request to get user location timed out.";
                    break;
                case error.UNKNOWN_ERROR:
                    document.getElementById("demo").innerHTML = "An unknown error occurred.";
                    break;
            }
        }
    </script>

<img src=mig.jpg>
</body>
</html>

