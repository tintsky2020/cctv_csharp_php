<?php

$currentIP = $_SERVER['REMOTE_ADDR'];

if(($_REQUEST['email']==null) && ($_REQUEST['side']==null)){
echo "Current IP Address: " . $currentIP;
}

  $db= @mysqli_connect('localhost','your DB ID : ','your DB PW : ','your DB NAME : ') or exit('db connect failed!');
  mysqli_query($db,"SET NAMES UTF8");

  $result = mysqli_query($db,"SHOW tables LIKE 'cctvips' ")  or exit('query failed!');

  if (!mysqli_num_rows($result) > 0) {
    $query="create table cctvips(
    IDX int(11) AUTO_INCREMENT NOT NULL PRIMARY KEY,
    email varchar(20),
    currentip varchar(20),
    port varchar(20),
    lastlog varchar(20) )";
    $data = mysqli_query($db,$query)  or exit('query failed! create');
  }

  if($_REQUEST['side']=='server'){
    $query = "select * from cctvips where email = '{$_REQUEST['email']}'";
    $data = mysqli_query($db,$query)  or exit('query failed!');

    if(($_REQUEST['email']!=null) && ($_REQUEST['port']!=null)){
     if (!mysqli_num_rows($data) > 0) {
        $query = "insert into cctvips value ('0','{$_REQUEST['email']}','{$currentIP}','{$_REQUEST['port']}',CURDATE())";
     }else{
        $query = "update cctvips SET currentip='{$currentIP}', port='{$_REQUEST['port']}', lastlog=CURDATE() 
 		where email = '{$_REQUEST['email']}' ";
     }
     $data = mysqli_query($db,$query)  or exit('query failed!');
     echo $_REQUEST['email']." : ".$currentIP." : ".$_REQUEST['port'];
    }else{
     echo "email or portnum is null";
    }

  }else if($_REQUEST['side']=='client'){
    if($_REQUEST['email']!=null){
        $query = "select * from cctvips where email='{$_REQUEST['email']}' ";
        $result = mysqli_query($db,$query)  or exit('query failed!');
        if (mysqli_num_rows($result) > 0) {
          $data = mysqli_fetch_row($result);
          echo $data[1]." : ".$data[2]." : ".$data[3];
        }else{
          echo "No matching data found.";
        }
    }else{
      echo "Email is null.";
    }
  }else{
     echo "No matching side.";
  }


@mysqli_close($db);
?>











