﻿namespace cctvcsharp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            button1 = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            timer2 = new System.Windows.Forms.Timer(components);
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button12 = new Button();
            pictureBox5 = new PictureBox();
            richTextBox1 = new RichTextBox();
            button17 = new Button();
            button18 = new Button();
            textBox11 = new TextBox();
            textBox12 = new TextBox();
            button19 = new Button();
            button20 = new Button();
            label11 = new Label();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            button21 = new Button();
            richTextBox2 = new RichTextBox();
            textBox13 = new TextBox();
            checksave = new CheckBox();
            checkbeep = new CheckBox();
            preparebtn = new Button();
            sensorcheck = new CheckBox();
            button3 = new Button();
            devichk = new CheckBox();
            mainpicturefix = new Button();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            previewcheckMain = new CheckBox();
            information = new CheckBox();
            randomname = new CheckBox();
            infoconnection = new CheckBox();
            textBox14 = new TextBox();
            label14 = new Label();
            listBox1 = new ListBox();
            OpenFolderBtn = new Button();
            ShowBtn = new Button();
            showDirectionBtn = new Button();
            timer3 = new System.Windows.Forms.Timer(components);
            ShowIntervalTxt = new TextBox();
            SPDAMOUNTTXT = new TextBox();
            label6 = new Label();
            label7 = new Label();
            button7 = new Button();
            sensedpreviewcheckbox = new CheckBox();
            contextMenuStrip1 = new ContextMenuStrip(components);
            hidetextcheckbox = new CheckBox();
            comboBox3 = new ComboBox();
            CCTVLISTCOMBOBOX = new ComboBox();
            locationtextBox = new TextBox();
            TLfoldertxt = new TextBox();
            TLpickbtn = new Button();
            TLminutestxt = new TextBox();
            TLcctvtxt = new TextBox();
            TLhourstxt = new TextBox();
            label3 = new Label();
            label4 = new Label();
            TLstartbtn = new Button();
            TLlabel5 = new Label();
            label5 = new Label();
            TLselfolderbtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(192, 41);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "list device";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(121, 11);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(61, 23);
            textBox1.TabIndex = 3;
            textBox1.Text = "3";
            textBox1.MouseClick += textBox1_MouseClick;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(217, 12);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(61, 23);
            textBox2.TabIndex = 4;
            textBox2.Text = "0.001";
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(64, 14);
            label1.Name = "label1";
            label1.Size = new Size(51, 15);
            label1.TabIndex = 9;
            label1.Text = "wish fps";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(188, 14);
            label2.Name = "label2";
            label2.Size = new Size(25, 15);
            label2.TabIndex = 10;
            label2.Text = "diff";
            // 
            // timer1
            // 
            timer1.Interval = 20;
            timer1.Tick += timer1_Tick;
            // 
            // timer2
            // 
            timer2.Interval = 1000;
            timer2.Tick += timer2_Tick;
            // 
            // button8
            // 
            button8.Location = new Point(90, 972);
            button8.Name = "button8";
            button8.Size = new Size(75, 23);
            button8.TabIndex = 19;
            button8.Text = "windowlist";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(422, 972);
            button9.Name = "button9";
            button9.Size = new Size(75, 23);
            button9.TabIndex = 23;
            button9.Text = "hidewindow";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(504, 972);
            button10.Name = "button10";
            button10.Size = new Size(75, 23);
            button10.TabIndex = 22;
            button10.Text = "showhidden";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button12
            // 
            button12.Location = new Point(342, 972);
            button12.Name = "button12";
            button12.Size = new Size(75, 23);
            button12.TabIndex = 20;
            button12.Text = "opensocket";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Location = new Point(585, 60);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(1297, 935);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 34;
            pictureBox5.TabStop = false;
            pictureBox5.WaitOnLoad = true;
            pictureBox5.LoadCompleted += pictureBox5_LoadCompleted;
            pictureBox5.MouseDown += pictureBox5_MouseDown;
            pictureBox5.MouseMove += pictureBox5_MouseMove;
            pictureBox5.MouseUp += pictureBox5_MouseUp;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(3, 513);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(285, 202);
            richTextBox1.TabIndex = 41;
            richTextBox1.Text = "";
            richTextBox1.TextChanged += richTextBox1_TextChanged;
            richTextBox1.MouseDoubleClick += richTextBox1_MouseDoubleClick;
            // 
            // button17
            // 
            button17.Location = new Point(972, 11);
            button17.Name = "button17";
            button17.Size = new Size(75, 23);
            button17.TabIndex = 42;
            button17.Text = "Host";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // button18
            // 
            button18.Location = new Point(1053, 11);
            button18.Name = "button18";
            button18.Size = new Size(75, 23);
            button18.TabIndex = 43;
            button18.Text = "safe close";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(431, 12);
            textBox11.Name = "textBox11";
            textBox11.PlaceholderText = "for get real ip";
            textBox11.Size = new Size(126, 23);
            textBox11.TabIndex = 44;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(563, 12);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(71, 23);
            textBox12.TabIndex = 45;
            // 
            // button19
            // 
            button19.Location = new Point(891, 11);
            button19.Name = "button19";
            button19.Size = new Size(75, 23);
            button19.TabIndex = 46;
            button19.Text = "Folder";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // button20
            // 
            button20.Location = new Point(729, 12);
            button20.Name = "button20";
            button20.Size = new Size(75, 23);
            button20.TabIndex = 47;
            button20.Text = "st1 extract";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(215, 0);
            label11.Name = "label11";
            label11.Size = new Size(316, 15);
            label11.TabIndex = 48;
            label11.Text = "This program is free software GNU General Public License";
            // 
            // button21
            // 
            button21.Location = new Point(810, 11);
            button21.Name = "button21";
            button21.Size = new Size(75, 23);
            button21.TabIndex = 49;
            button21.Text = "TCPHost";
            button21.UseVisualStyleBackColor = true;
            // 
            // richTextBox2
            // 
            richTextBox2.Location = new Point(3, 721);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.Size = new Size(285, 186);
            richTextBox2.TabIndex = 50;
            richTextBox2.Text = "";
            // 
            // textBox13
            // 
            textBox13.Location = new Point(294, 12);
            textBox13.Name = "textBox13";
            textBox13.PlaceholderText = "put your email address";
            textBox13.Size = new Size(131, 23);
            textBox13.TabIndex = 51;
            // 
            // checksave
            // 
            checksave.AutoSize = true;
            checksave.Location = new Point(1189, 0);
            checksave.Name = "checksave";
            checksave.Size = new Size(69, 19);
            checksave.TabIndex = 54;
            checksave.Text = "SaveFile";
            checksave.TextAlign = ContentAlignment.MiddleCenter;
            checksave.UseVisualStyleBackColor = true;
            // 
            // checkbeep
            // 
            checkbeep.AutoSize = true;
            checkbeep.Location = new Point(1141, 0);
            checkbeep.Name = "checkbeep";
            checkbeep.Size = new Size(52, 19);
            checkbeep.TabIndex = 53;
            checkbeep.Text = "beep";
            checkbeep.UseVisualStyleBackColor = true;
            // 
            // preparebtn
            // 
            preparebtn.Location = new Point(640, 12);
            preparebtn.Name = "preparebtn";
            preparebtn.Size = new Size(75, 23);
            preparebtn.TabIndex = 59;
            preparebtn.Text = "email chg";
            preparebtn.UseVisualStyleBackColor = true;
            preparebtn.Click += preparebtn_Click;
            // 
            // sensorcheck
            // 
            sensorcheck.AutoSize = true;
            sensorcheck.Location = new Point(1141, 21);
            sensorcheck.Name = "sensorcheck";
            sensorcheck.Size = new Size(59, 19);
            sensorcheck.TabIndex = 61;
            sensorcheck.Text = "senser";
            sensorcheck.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(9, 972);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 62;
            button3.Text = "deviceck";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // devichk
            // 
            devichk.AutoSize = true;
            devichk.Location = new Point(1189, 21);
            devichk.Name = "devichk";
            devichk.Size = new Size(67, 19);
            devichk.TabIndex = 63;
            devichk.Text = "devichk";
            devichk.UseVisualStyleBackColor = true;
            devichk.CheckedChanged += devichk_CheckedChanged;
            // 
            // mainpicturefix
            // 
            mainpicturefix.Location = new Point(171, 972);
            mainpicturefix.Name = "mainpicturefix";
            mainpicturefix.Size = new Size(75, 23);
            mainpicturefix.TabIndex = 64;
            mainpicturefix.Text = "mainpicturefix";
            mainpicturefix.UseVisualStyleBackColor = true;
            mainpicturefix.Click += mainpicturefix_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(273, 41);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(109, 23);
            comboBox1.TabIndex = 66;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(388, 41);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(109, 23);
            comboBox2.TabIndex = 67;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // previewcheckMain
            // 
            previewcheckMain.AutoSize = true;
            previewcheckMain.Checked = true;
            previewcheckMain.CheckState = CheckState.Checked;
            previewcheckMain.Location = new Point(585, 41);
            previewcheckMain.Name = "previewcheckMain";
            previewcheckMain.Size = new Size(125, 19);
            previewcheckMain.TabIndex = 72;
            previewcheckMain.Text = "previewcheckMain";
            previewcheckMain.UseVisualStyleBackColor = true;
            // 
            // information
            // 
            information.AutoSize = true;
            information.Checked = true;
            information.CheckState = CheckState.Checked;
            information.Location = new Point(715, 41);
            information.Name = "information";
            information.Size = new Size(89, 19);
            information.TabIndex = 77;
            information.Text = "information";
            information.UseVisualStyleBackColor = true;
            // 
            // randomname
            // 
            randomname.AutoSize = true;
            randomname.Location = new Point(1641, -1);
            randomname.Name = "randomname";
            randomname.Size = new Size(98, 19);
            randomname.TabIndex = 78;
            randomname.Text = "randomname";
            randomname.UseVisualStyleBackColor = true;
            // 
            // infoconnection
            // 
            infoconnection.AutoSize = true;
            infoconnection.Checked = true;
            infoconnection.CheckState = CheckState.Checked;
            infoconnection.Location = new Point(810, 40);
            infoconnection.Name = "infoconnection";
            infoconnection.Size = new Size(107, 19);
            infoconnection.TabIndex = 79;
            infoconnection.Text = "infoconnection";
            infoconnection.UseVisualStyleBackColor = true;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(1641, 17);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(241, 23);
            textBox14.TabIndex = 80;
            textBox14.KeyDown += textBox14_KeyDown;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(1512, 19);
            label14.Name = "label14";
            label14.Size = new Size(123, 15);
            label14.TabIndex = 82;
            label14.Text = "Regist Unhide Hotkey";
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(294, 513);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(285, 394);
            listBox1.TabIndex = 83;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // OpenFolderBtn
            // 
            OpenFolderBtn.Location = new Point(294, 70);
            OpenFolderBtn.Name = "OpenFolderBtn";
            OpenFolderBtn.Size = new Size(75, 23);
            OpenFolderBtn.TabIndex = 84;
            OpenFolderBtn.Text = "OpenFolder";
            OpenFolderBtn.UseVisualStyleBackColor = true;
            OpenFolderBtn.Click += OpenFolderBtn_Click;
            // 
            // ShowBtn
            // 
            ShowBtn.Enabled = false;
            ShowBtn.Location = new Point(423, 70);
            ShowBtn.Name = "ShowBtn";
            ShowBtn.Size = new Size(75, 23);
            ShowBtn.TabIndex = 85;
            ShowBtn.Text = "Show";
            ShowBtn.UseVisualStyleBackColor = true;
            ShowBtn.Click += ShowBtn_Click;
            // 
            // showDirectionBtn
            // 
            showDirectionBtn.Location = new Point(504, 70);
            showDirectionBtn.Name = "showDirectionBtn";
            showDirectionBtn.Size = new Size(75, 23);
            showDirectionBtn.TabIndex = 86;
            showDirectionBtn.Text = ">>>";
            showDirectionBtn.UseVisualStyleBackColor = true;
            showDirectionBtn.Click += showDirectionBtn_Click;
            // 
            // timer3
            // 
            timer3.Tick += timer3_Tick;
            // 
            // ShowIntervalTxt
            // 
            ShowIntervalTxt.Location = new Point(86, 71);
            ShowIntervalTxt.Name = "ShowIntervalTxt";
            ShowIntervalTxt.Size = new Size(50, 23);
            ShowIntervalTxt.TabIndex = 89;
            ShowIntervalTxt.Text = "100";
            ShowIntervalTxt.TextChanged += ShowIntervalTxt_TextChanged;
            // 
            // SPDAMOUNTTXT
            // 
            SPDAMOUNTTXT.Location = new Point(236, 71);
            SPDAMOUNTTXT.Name = "SPDAMOUNTTXT";
            SPDAMOUNTTXT.Size = new Size(52, 23);
            SPDAMOUNTTXT.TabIndex = 90;
            SPDAMOUNTTXT.Text = "1";
            SPDAMOUNTTXT.TextChanged += SPDAMOUNTTXT_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(5, 74);
            label6.Name = "label6";
            label6.Size = new Size(80, 15);
            label6.TabIndex = 91;
            label6.Text = "Show Interval";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(150, 74);
            label7.Name = "label7";
            label7.Size = new Size(76, 15);
            label7.TabIndex = 92;
            label7.Text = "Skip amount";
            // 
            // button7
            // 
            button7.Location = new Point(375, 70);
            button7.Name = "button7";
            button7.Size = new Size(42, 23);
            button7.TabIndex = 94;
            button7.Text = "load";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // sensedpreviewcheckbox
            // 
            sensedpreviewcheckbox.AutoSize = true;
            sensedpreviewcheckbox.Location = new Point(923, 40);
            sensedpreviewcheckbox.Name = "sensedpreviewcheckbox";
            sensedpreviewcheckbox.Size = new Size(107, 19);
            sensedpreviewcheckbox.TabIndex = 95;
            sensedpreviewcheckbox.Text = "sensed preview";
            sensedpreviewcheckbox.UseVisualStyleBackColor = true;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // hidetextcheckbox
            // 
            hidetextcheckbox.AutoSize = true;
            hidetextcheckbox.Checked = true;
            hidetextcheckbox.CheckState = CheckState.Checked;
            hidetextcheckbox.Location = new Point(1035, 40);
            hidetextcheckbox.Name = "hidetextcheckbox";
            hidetextcheckbox.Size = new Size(124, 19);
            hidetextcheckbox.TabIndex = 99;
            hidetextcheckbox.Text = "hide richtextboxes";
            hidetextcheckbox.UseVisualStyleBackColor = true;
            hidetextcheckbox.CheckedChanged += hidetextcheckbox_CheckedChanged;
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(3, 41);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(82, 23);
            comboBox3.TabIndex = 100;
            comboBox3.SelectedIndexChanged += comboBox3_SelectedIndexChanged;
            // 
            // CCTVLISTCOMBOBOX
            // 
            CCTVLISTCOMBOBOX.FormattingEnabled = true;
            CCTVLISTCOMBOBOX.Location = new Point(1262, 13);
            CCTVLISTCOMBOBOX.Name = "CCTVLISTCOMBOBOX";
            CCTVLISTCOMBOBOX.Size = new Size(121, 23);
            CCTVLISTCOMBOBOX.TabIndex = 101;
            // 
            // locationtextBox
            // 
            locationtextBox.Location = new Point(91, 41);
            locationtextBox.Name = "locationtextBox";
            locationtextBox.PlaceholderText = "cctv location";
            locationtextBox.Size = new Size(95, 23);
            locationtextBox.TabIndex = 102;
            // 
            // TLfoldertxt
            // 
            TLfoldertxt.Location = new Point(292, 943);
            TLfoldertxt.Name = "TLfoldertxt";
            TLfoldertxt.PlaceholderText = "folder";
            TLfoldertxt.Size = new Size(100, 23);
            TLfoldertxt.TabIndex = 103;
            // 
            // TLpickbtn
            // 
            TLpickbtn.Location = new Point(504, 943);
            TLpickbtn.Name = "TLpickbtn";
            TLpickbtn.Size = new Size(75, 23);
            TLpickbtn.TabIndex = 104;
            TLpickbtn.Text = "Select";
            TLpickbtn.UseVisualStyleBackColor = true;
            TLpickbtn.Click += TLpickbtn_Click;
            // 
            // TLminutestxt
            // 
            TLminutestxt.Location = new Point(186, 943);
            TLminutestxt.Name = "TLminutestxt";
            TLminutestxt.PlaceholderText = "Minutes";
            TLminutestxt.Size = new Size(100, 23);
            TLminutestxt.TabIndex = 105;
            TLminutestxt.KeyDown += TLminutestxt_KeyDown;
            // 
            // TLcctvtxt
            // 
            TLcctvtxt.Location = new Point(398, 943);
            TLcctvtxt.Name = "TLcctvtxt";
            TLcctvtxt.PlaceholderText = "select cctv";
            TLcctvtxt.Size = new Size(100, 23);
            TLcctvtxt.TabIndex = 106;
            // 
            // TLhourstxt
            // 
            TLhourstxt.Location = new Point(80, 943);
            TLhourstxt.Name = "TLhourstxt";
            TLhourstxt.PlaceholderText = "Hours";
            TLhourstxt.Size = new Size(100, 23);
            TLhourstxt.TabIndex = 107;
            TLhourstxt.KeyDown += TLhourstxt_KeyDown;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(28, 947);
            label3.Name = "label3";
            label3.Size = new Size(46, 15);
            label3.TabIndex = 108;
            label3.Text = "interval";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(393, 921);
            label4.Name = "label4";
            label4.Size = new Size(104, 15);
            label4.TabIndex = 109;
            label4.Text = "Time lapse setting";
            // 
            // TLstartbtn
            // 
            TLstartbtn.Location = new Point(503, 917);
            TLstartbtn.Name = "TLstartbtn";
            TLstartbtn.Size = new Size(75, 23);
            TLstartbtn.TabIndex = 110;
            TLstartbtn.Text = "Start";
            TLstartbtn.UseVisualStyleBackColor = true;
            TLstartbtn.Click += TLstartbtn_Click;
            // 
            // TLlabel5
            // 
            TLlabel5.AutoSize = true;
            TLlabel5.Location = new Point(306, 921);
            TLlabel5.Name = "TLlabel5";
            TLlabel5.Size = new Size(26, 15);
            TLlabel5.TabIndex = 111;
            TLlabel5.Text = "60s";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(157, 921);
            label5.Name = "label5";
            label5.Size = new Size(131, 15);
            label5.TabIndex = 112;
            label5.Text = "current / aim secconds";
            // 
            // TLselfolderbtn
            // 
            TLselfolderbtn.Location = new Point(9, 917);
            TLselfolderbtn.Name = "TLselfolderbtn";
            TLselfolderbtn.Size = new Size(142, 23);
            TLselfolderbtn.TabIndex = 113;
            TLselfolderbtn.Text = "Select Current TLfolder";
            TLselfolderbtn.UseVisualStyleBackColor = true;
            TLselfolderbtn.Click += TLselfolderbtn_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1894, 1001);
            Controls.Add(TLselfolderbtn);
            Controls.Add(label5);
            Controls.Add(TLlabel5);
            Controls.Add(TLstartbtn);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(TLhourstxt);
            Controls.Add(TLcctvtxt);
            Controls.Add(TLminutestxt);
            Controls.Add(TLpickbtn);
            Controls.Add(TLfoldertxt);
            Controls.Add(locationtextBox);
            Controls.Add(CCTVLISTCOMBOBOX);
            Controls.Add(comboBox3);
            Controls.Add(hidetextcheckbox);
            Controls.Add(sensedpreviewcheckbox);
            Controls.Add(button7);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(SPDAMOUNTTXT);
            Controls.Add(ShowIntervalTxt);
            Controls.Add(showDirectionBtn);
            Controls.Add(ShowBtn);
            Controls.Add(OpenFolderBtn);
            Controls.Add(listBox1);
            Controls.Add(label14);
            Controls.Add(textBox14);
            Controls.Add(infoconnection);
            Controls.Add(randomname);
            Controls.Add(information);
            Controls.Add(previewcheckMain);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(mainpicturefix);
            Controls.Add(devichk);
            Controls.Add(button3);
            Controls.Add(sensorcheck);
            Controls.Add(preparebtn);
            Controls.Add(checksave);
            Controls.Add(checkbeep);
            Controls.Add(textBox13);
            Controls.Add(richTextBox2);
            Controls.Add(button21);
            Controls.Add(label11);
            Controls.Add(button20);
            Controls.Add(button19);
            Controls.Add(textBox12);
            Controls.Add(textBox11);
            Controls.Add(button18);
            Controls.Add(button17);
            Controls.Add(richTextBox1);
            Controls.Add(pictureBox5);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button12);
            Controls.Add(button8);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(button1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterParent;
            Text = "COREAFACTORY.COM";
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button1;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label1;
        private Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button12;
        private PictureBox pictureBox5;
        private RichTextBox richTextBox1;
        private Button button17;
        private Button button18;
        private TextBox textBox11;
        private TextBox textBox12;
        private Button button19;
        private Button button20;
        private Label label11;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private Button button21;
        private RichTextBox richTextBox2;
        private TextBox textBox13;
        private CheckBox checksave;
        private CheckBox checkbeep;
        private Button preparebtn;
        private CheckBox sensorcheck;
        private Button button3;
        private CheckBox devichk;
        private Button mainpicturefix;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private CheckBox previewcheckMain;
        private CheckBox information;
        private CheckBox randomname;
        private CheckBox infoconnection;
        private TextBox textBox14;
        private Label label14;
        private ListBox listBox1;
        private Button OpenFolderBtn;
        private Button ShowBtn;
        private Button showDirectionBtn;
        private System.Windows.Forms.Timer timer3;
        private TextBox ShowIntervalTxt;
        private TextBox SPDAMOUNTTXT;
        private Label label6;
        private Label label7;
        private Button button7;
        private CheckBox sensedpreviewcheckbox;
        private ContextMenuStrip contextMenuStrip1;
        private CheckBox hidetextcheckbox;
        private ComboBox comboBox3;
        private ComboBox CCTVLISTCOMBOBOX;
        private TextBox locationtextBox;
        private TextBox TLfoldertxt;
        private Button TLpickbtn;
        private TextBox TLminutestxt;
        private TextBox TLcctvtxt;
        private TextBox TLhourstxt;
        private Label label3;
        private Label label4;
        private Button TLstartbtn;
        private Label TLlabel5;
        private Label label5;
        private Button TLselfolderbtn;
    }
}